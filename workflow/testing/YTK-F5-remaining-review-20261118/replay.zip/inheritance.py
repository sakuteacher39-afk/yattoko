import os
import json,tempfile
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parent
allowed={'index.html','storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'}
read="""async()=>{const {openDatabase,CanonicalStore}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def mark(case,**v):log.setdefault(case,[]).append(v)
with sync_playwright() as w:
 for apply_first in [False]:
  with tempfile.TemporaryDirectory() as profile:
   def boot():
    ctx=w.chromium.launch_persistent_context(profile,executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'],viewport={'width':390,'height':844})
    def route(r):
     path=urlparse(r.request.url);name=path.path.removeprefix('/').removeprefix('src/')
     if path.netloc=='localhost' and name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
     else:r.abort()
    ctx.route('**/*',route);page=ctx.pages[0];page.set_default_timeout(5000);page.goto('http://localhost/index.html');page.locator('#restore-file').wait_for();return ctx,page
   c,p=boot()
   def loc(v):return p.locator('#'+v)
   def verify():
    loc('restore-file').set_input_files(root/'fixture-data/EM-FULL.json');loc('restore-verify').click();loc('restore-ack').check();expect(loc('restore-commit')).to_be_enabled()
   def db():return p.evaluate(read)
   p.locator('#restore-file').set_input_files(root/'fixture-data/V-VALID-01.json');loc('restore-verify').click();loc('restore-ack').check();loc('restore-commit').click();p.wait_for_function("async()=>("+read+")().then(d=>d?.services.length===3)")
   p.reload()
   def listing():
    def click(v):p.get_by_role('button',name=v,exact=True).click()
    click('整理をはじめる')
    for v in ['次へ','次へ','次へ','結果を見る','詳しく整理する','カテゴリを選ぶ','このカテゴリを整理']:click(v)
    p.locator('.r2-service-grid button').first.click();click('わからない');p.wait_for_selector('.choice.on');click('必要なことだけ確認')
    if p.get_by_role('button',name='次の質問',exact=True).count():click('次の質問')
    click('本人の意向へ');click('この1件を整理完了');click('一覧を見る')
    returnd={}
    for nm in ['試験未回答親','試験サービス','試験完了']:
     returnd[nm]=p.locator('.r2-row').filter(has=p.get_by_role('heading',name=nm,exact=True)).inner_text()
    return returnd
   for stage,case in [('initial','03'),('reload','04'),('restart','05')]:
    if stage=='reload':p.reload()
    if stage=='restart':c.close();c,p=boot()
    rows=listing();d=db();parent=next(r for r in d['categories'] if r['categoryKey']=='base');child=next(r for r in d['services'] if r['otherServiceName']=='試験未回答親')
    assert parent['intention']=='unanswered' and child['intentionOverride'] is None and '未決定（カテゴリと同じ）' in rows['試験未回答親'];mark('F2:R09-'+case,stage=stage,row=rows['試験未回答親'],parent=parent,child=child)
    assert '未決定（カテゴリと同じ）' in rows['試験サービス'];mark('F2:R07-06',stage=stage,row=rows['試験サービス'],parent=next(r for r in d['categories'] if r['categoryKey']=='device'))
    mark('F2:R2INT-16',stage=stage,partial=rows['試験サービス'],completed=rows['試験完了'])
   c.close()
(root/'inheritance-results.json').write_text(json.dumps(log,ensure_ascii=False));print(list(log))
