import os
from pathlib import Path
import json,tempfile,mimetypes
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse
root=Path(__file__).resolve().parent
read="""async()=>{const {CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def proof(n,data):log.setdefault('F2:PART-'+str(n).zfill(2),[]).append(data)
allowed={'index.html',*(p.name for p in root.glob('*.mjs') if p.name in {'storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'})}
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'])
 for i in range(12):
  c=b.new_context(viewport={'width':390,'height':844});p=c.new_page();p.set_default_timeout(4500)
  def route(r):
   path=urlparse(r.request.url).path.removeprefix('/');name=path.removeprefix('src/')
   if name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
   else:r.abort()
  c.route('**/*',route)
  def click(label):p.get_by_role('button',name=label,exact=True).click()
  def start():click('整理をはじめる')
  def db():return p.evaluate(read)
  p.goto('http://localhost/index.html');start();cards=p.locator('.card');assert cards.count()==12 and p.locator('.choice.on').count()==0 and db() is None
  j=i%5
  cards.nth(i).get_by_text('わからない',exact=True).click();p.wait_for_selector('.choice.on');d=db();assert d['globalRevision']==1
  p.reload();start();assert p.locator('.choice.on').count()==1 and cards.nth(i).locator('.choice.on').inner_text()=='わからない' and db()==d
  others=[v for v in d['categories'] if v['usageStatus']=='unanswered'];assert len(others)==11
  proof(5,{'category':i,'untouched':len(others),'selected':'わからない'})
  cards.nth(i).get_by_text('わからない',exact=True).click();click('次へ');assert db()==d
  q=p.locator('.detail');assert q.count()==5 and p.locator('.choice.on').count()==0 and all(d['overview'][k]=='unanswered' for k in ['identity','billing','finance','data','family'])
  proof(1,{'category':i,'emptyCategories':12,'emptyOverview':5,'initialDB':None})
  q.nth(j).get_by_text('わからない',exact=True).click();p.wait_for_selector('.choice.on');after=db();assert after['globalRevision']==2
  p.reload();start();click('次へ');assert p.locator('.choice.on').count()==1 and q.nth(j).locator('.choice.on').inner_text()=='わからない' and db()==after
  proof(6,{'question':j,'overview':after['overview']})
  q.nth(j).get_by_text('わからない',exact=True).click();click('次へ');click('戻る');assert db()==after
  proof(11,{'category':i,'question':j,'global':[1,1,2,2]})
  click('戻る');click('次へ');click('次へ');assert db()==after
  proof(13,{'category':i,'global':after['globalRevision'],'allRecordsEqual':True})
  c.close()
 print(b.version,{k:len(v) for k,v in log.items()});(root/'browser-results.json').write_text(json.dumps({'version':b.version,'results':log},ensure_ascii=False));b.close()
