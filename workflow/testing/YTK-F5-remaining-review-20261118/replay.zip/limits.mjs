import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {fixtures,read,newStore,parse,sign,envelope,install,cat,fingerprint,snapshot} from './setup.mjs';
import {prepareRestore,commitRestore} from './restore.mjs';
import {ReapplySession} from './reapply.mjs';
import * as C from './canonical.mjs';
import {createBackup} from './backup.mjs';
const proof={},file=id=>JSON.parse(read('fixture-data/'+id+'.json'));
{
 const s=await newStore(),t=await parse(file('V-VALID-01'));await install(s,t);const old=await s.read(),plan=await prepareRestore(s,t),large=file('DS-BYTES-10000001'),tr=s.db.transaction.bind(s.db),stages=[];let readCount=0;
 s.db.transaction=(names,mode)=>{const tx=tr(names,mode);if(mode!=='readwrite')return tx;
 for(const name of names){const os=tx.objectStore(name),get=os.getAll.bind(os);os.getAll=()=>{const req=get();if(++readCount>4)req.addEventListener('success',()=>{const actual=req.result,copy=structuredClone(large);if(name==='meta'){const {overview,categories,services,...meta}=copy;meta.generationId=actual[0].generationId;Object.defineProperty(req,'result',{value:[{key:'current',...meta}]})}else Object.defineProperty(req,'result',{value:name==='overview'?[copy.overview]:copy[name]});stages.push(name)});return req;};}return tx;};
 assert.equal(C.capacity(large),10000001);await assert.rejects(commitRestore(s,plan,{confirmed:true}));assert.equal(stages.length,4);assert.deepEqual(await s.read(),old);proof['F3:R03-35']={size:C.capacity(large),stages,unchanged:fingerprint(old)};s.close();
}
{
 const full=file('DS-BYTES-10000000'),s=await newStore();assert.equal(C.capacity(full),1e7);const op={type:'addService',categoryKey:'mail',recordId:C.id('svc'),serviceCatalogId:'other',otherServiceName:'追加試験'};
 const backup=JSON.parse(new TextDecoder().decode((await createBackup({read:async()=>full},{kind:'emergency',pending:[{base:full,operation:op}]})).bytes));
 assert.equal(backup.pending.exportedCount,1);const t=await parse(backup),r=await install(s,t),session=new ReapplySession(s,r),before=fingerprint(await s.read());
 await assert.rejects(session.apply(t,backup.pending.operations[0].operationId,{confirmed:true}),{code:'capacity'});assert.deepEqual(session.status.appliedOperationIds,[]);assert.deepEqual(fingerprint(await s.read()),before);proof['F3:R05-25']={size:1e7,pending:1,receipts:0,before};s.close();
}
writeFileSync('limits-results.json',JSON.stringify(proof));console.log(Object.keys(proof));
