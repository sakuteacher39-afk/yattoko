import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {IDBFactory} from 'fake-indexeddb';
import {read,parse,sign,newStore,install,snapshot,cat,fingerprint} from './setup.mjs';
import * as C from './canonical.mjs';
import {CanonicalStore,openDatabase} from './storage.mjs';
import * as R from './restore.mjs';
import {ReapplySession} from './reapply.mjs';
const results={},add=(group,n,v)=>(results[group+'-'+String(n).padStart(2,'0')]??=[]).push(v);
const file=id=>JSON.parse(read('fixture-data/'+id+'.json'));
for(const id of ['EM-FULL','EM-PARTIAL']){
 const obj=file(id),f=await parse(obj),op=obj.pending.operations[0],first=op.operationId;
 for(const n of [1,2,3,6,7,8,9,13,14,15,17,18,20,21,36]){
  const fac=new IDBFactory(),s=new CanonicalStore(await openDatabase(fac)),other=new CanonicalStore(await openDatabase(fac)),plan=await R.prepareRestore(s,f);
  const observe=x=>add('F3:R05',n,{id,first,...x});
  if(n===3){await other.save(null,cat('device','using'));await assert.rejects(R.commitRestore(s,plan,{confirmed:true}),{code:'CONFLICT'});assert.throws(()=>new ReapplySession(s,plan),{code:'UNPROVEN'});observe({created:false});s.close();other.close();continue;}
  if(n===2)assert.throws(()=>new ReapplySession(s,plan),{code:'UNPROVEN'});
  const r=await R.commitRestore(s,plan,{confirmed:true}),session=new ReapplySession(s,r),apply=()=>session.apply(f,first,{confirmed:true});
  if(n===1||n===2){assert.equal(session.status.state,'ACTIVE');assert.deepEqual(session.status.appliedOperationIds,[]);assert.deepEqual(r.dataset.categories,obj.snapshot.categories);assert.deepEqual(session.status.remainingOperationIds,obj.pending.operations.map(v=>v.operationId));}
  if([6,9].includes(n)){await install(other,f);await assert.rejects(session.check(f));assert.equal(session.status.state,'INVALIDATED');}
  if([7,8,14,15,21].includes(n)){
   if(n===14)await apply();const same=[8,15,21].includes(n),external=same?cat(op.categoryKey,op.canonicalValue.value):cat('social','unknown');await other.save(await other.read(),external);
   const original=await other.read(),receipts=session.status.appliedOperationIds;let error;try{await apply()}catch(e){error=e.code}assert(error);assert.deepEqual(session.status.appliedOperationIds,receipts);assert.deepEqual(await s.read(),original);assert.equal(session.status.state,'INVALIDATED');observe({error,expected:n===8?'AMBIGUOUS_SAME_VALUE':'refused',after:fingerprint(original),receipts});
  }
  if(n===13){const a=await apply(),before=await other.read(),b=await apply();assert.deepEqual(a.receipt,b.receipt);assert.equal(b.status,'ALREADY_APPLIED');assert.equal(a.receipt.operationKey,f.sourceFileId+':'+first);assert.equal(a.receipt.resultingGenerationId,before.generationId);assert.equal(a.receipt.resultingGlobalRevision,before.globalRevision);assert.deepEqual(await s.read(),before);}
  if(n===17){const a=apply();await assert.rejects(apply(),{code:'IN_FLIGHT'});assert.equal((await a).status,'APPLIED');assert.equal(session.status.appliedOperationIds.length,1);}
  if(n===18){const tx=s.db.transaction.bind(s.db);s.db.transaction=(a,m)=>{const t=tx(a,m);if(m==='readwrite'){const os=t.objectStore('meta'),fn=os.put.bind(os);os.put=v=>{const req=fn(v);req.addEventListener('success',()=>t.abort());return req}}return t};await assert.rejects(apply());assert.deepEqual(await other.read(),r.dataset);assert.deepEqual(session.status.appliedOperationIds,[]);}
  if(n===20){assert.throws(()=>new ReapplySession(other,r),{code:'UNPROVEN'});}
  if(n===36){await apply();const d=await other.read();assert(!/sourceFileId|operationId|receipt/.test(JSON.stringify(d)));assert.deepEqual([...other.db.objectStoreNames].sort(),['categories','meta','overview','services']);}
  observe({file:fingerprint(obj),session:session.status,after:fingerprint(await other.read())});s.close();other.close();
 }
 for(const [n,k] of [[19,'baseSnapshotChecksumSha256'],[20,'baseContentFingerprintSha256']]){const {checksum,...body}=structuredClone(obj);body.pending[k]='0'.repeat(64);await assert.rejects(parse(sign(body)));add('F3:R01',n,{id,changed:k,rejected:true});}
}
const s=await newStore();await install(s,await parse(file('V-VALID-01')));let d=await s.read();await s.save(d,cat('mail','unknown'));d=await s.read();
const tr=s.db.transaction.bind(s.db),modes=[];s.db.transaction=(a,m)=>{modes.push(m);return tr(a,m)};
const o=await snapshot(s,{pending:[{base:d,operation:cat('social','unknown')}],draft:{categoryKey:'mail',otherServiceName:'UncommittedMarker'}});
assert.deepEqual(modes,['readonly']);assert.deepEqual(o.snapshot,d);assert.deepEqual(await s.read(),d);assert.equal(o.kind,'normal');assert.equal(o.pending,null);assert(!/UncommittedMarker|mutationSeq|inheritedIntention|history/.test(JSON.stringify(o)));assert.deepEqual(new Set(d.services.map(r=>r.recordState)),new Set(['partial','completed']));assert(d.categories.some(r=>r.usageStatus==='unknown'));assert(d.categories.some(r=>r.usageStatus==='unanswered'));
for(const n of [2,3,4,5,6,9])add('F3:N',n,{snapshot:fingerprint(o.snapshot),before:fingerprint(d),kind:o.kind,pending:o.pending,exportTransactions:modes.slice(0,1)});
for(const n of [3,4,15,16,17,18]){
 const fac=new IDBFactory(),store=new CanonicalStore(await openDatabase(fac)),other=new CanonicalStore(await openDatabase(fac));await install(store,await parse(file('V-VALID-01')));const base=await store.read(),entry={base:structuredClone(base),operation:cat('social','unknown')};
 if(n===16)await other.save(base,cat('mail','using'));if(n===17)await other.save(base,{type:'deleteAll'});if(n===18)entry.base.categories.find(r=>r.categoryKey==='social').revision++;
 const draft={categoryKey:'mail',otherServiceName:n===3?' e\u0301 ':'password SECRET'},opts=n<5?{kind:'emergency',draft,draftBase:base}:{kind:'emergency',pending:[entry]};
 const pre=await other.read(),b=await snapshot(store,opts);await parse(b);assert.deepEqual(await store.read(),pre);
 if(n===3)assert.equal(b.pending.operations[0].canonicalValue.otherServiceName,'é');if(n===4){assert(!JSON.stringify(b).includes('SECRET'));assert.equal(b.pending.omittedCount,1);}
 if(n>=15){assert.equal(b.pending.exportedCount,n===15?1:0);if(n!==15)assert.equal(b.pending.omittedScopes[0].reasonCode,'BASE_CONFLICT');}
 add('F3:R01',n,{after:fingerprint(pre),exported:b.pending.exportedCount,omitted:b.pending.omittedCount,reasons:b.pending.omittedScopes.map(x=>x.reasonCode)});store.close();other.close();
}
s.close();writeFileSync('backup-results.json',JSON.stringify(results));console.log(Object.keys(results).length);
