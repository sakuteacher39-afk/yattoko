import os
import json,re,hashlib
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parent
files={'index.html','storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'}
read="""async()=>{const {openDatabase,CanonicalStore}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def mark(case,**v):log.setdefault(case,[]).append(v)
def encoded(data):return json.dumps(data,ensure_ascii=False,separators=(',',':')).encode()
def signed(body):return encoded({**body,'checksum':{'algorithm':'SHA-256','hex':hashlib.sha256(encoded(body)).hexdigest()}})
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox']);c=b.new_context();p=c.new_page();p.set_default_timeout(5000)
 reqs=[];console=[];ws=[];paths=[];free=[]
 c.on('request',lambda r:reqs.append((r.method,r.url,r.post_data)));p.on('websocket',lambda r:ws.append(r.url));p.on('console',lambda x:console.append(x.text));p.on('pageerror',lambda e:console.append(str(e)))
 def route(r):
  url=urlparse(r.request.url);n=url.path.strip('/').removeprefix('src/')
  if url.netloc=='localhost' and n in files:r.fulfill(body=(root/n).read_bytes(),content_type='text/html' if n=='index.html' else 'text/javascript')
  else:r.abort()
 c.route('**/*',route);p.goto('http://localhost/index.html');get=lambda v:p.locator('#'+v)
 def click(v):
  p.get_by_role('button',name=v,exact=True).click();free.extend(p.locator('#app textarea,#app [contenteditable=true]').count() for _ in [0])
 def db():return p.evaluate(read)
 click('整理をはじめる');p.locator('.card').first.get_by_text('使っている',exact=True).click();p.wait_for_selector('.choice.on')
 for btn in ['次へ','次へ','次へ','結果を見る','詳しく整理する','カテゴリを選ぶ','このカテゴリを整理','その他']:click(btn)
 marker='<b>検証用表示</b>';p.locator('input[type=text]').fill(marker);click('利用状態へ');p.locator('.r2-meta').wait_for();pill=p.locator('.r2-meta .r2-pill').last;assert pill.inner_text()==marker and pill.locator('*').count()==0
 click('利用中');p.wait_for_selector('.choice.on');click('必要なことだけ確認')
 if p.get_by_role('button',name='次の質問',exact=True).count():click('次の質問')
 click('本人の意向へ');click('この1件を整理完了');click('一覧を見る');h=p.locator('.r2-row h3');assert h.inner_text()==marker and h.locator('*').count()==0
 mark('F2:SEC-03',field=marker,asText=h.inner_text(),childElements=h.locator('*').count())
 assert not any(free);assert not re.search(r'createElement\(["\x27]textarea|(?:<textarea\b|contenteditable\s*=\s*["\x27]true)',(root/'index.html').read_text(),re.I)
 mark('F2:SEC-02',screenCounts=free,onlyDetailText=p.locator('.r2-row h3').inner_text())
 get('backup-ack').check();click('通常バックアップを作成');expect(get('backup-status')).to_contain_text('確定済みデータだけ')
 before=db();base=json.load(open(root/'fixture-data/V-VALID-01.json'));base.pop('checksum')
 for key in ['password','pin','otp','recoveryCode','privateKey','seedPhrase','cardNumber','apiKey','__proto__','constructor','prototype']:
  obj=json.loads(json.dumps(base));obj['snapshot']['services'][0][key]='inert-test-marker'
  current=signed(obj);stale=json.loads(current);stale['checksum']=json.load(open(root/'fixture-data/V-VALID-01.json'))['checksum']
  for mode,payload in [('resigned',current),('stale',encoded(stale))]:
   get('restore-file').set_input_files({'name':'negative.json','mimeType':'application/json','buffer':payload});click('検証して復元内容を確認');expect(get('restore-status')).to_contain_text('自動適用しません');assert get('restore-commit').is_disabled() and db()==before
   mark('F2:SEC-04' if key in ['__proto__','constructor','prototype'] else 'F2:SEC-01',mode=mode,unknownKey=key,checksum=hashlib.sha256(payload).hexdigest(),committed=False)
 assert all(method=='GET' and body is None and urlparse(url).netloc=='localhost' for method,url,body in reqs) and not ws
 assert not any(marker in msg or 'inert-test-marker' in msg for msg in console)
 mark('F2:SEC-05',fixture=marker,console=console);mark('F2:SEC-06',requests=reqs,websockets=ws)
 pattern=r'\b(?:sendBeacon|XMLHttpRequest|WebSocket|EventSource|gtag|dataLayer|Sentry|LogRocket|FullStory|rrweb)\b|\bfetch\s*\('
 hits=[n for n in files if re.search(pattern,(root/n).read_text())];assert hits==[];mark('F2:SEC-07',checkedModules=sorted(files),networkEntries=reqs,hooksFound=hits)
 b.close()
(root/'privacy-results.json').write_text(json.dumps(log,ensure_ascii=False));print(list(log))
