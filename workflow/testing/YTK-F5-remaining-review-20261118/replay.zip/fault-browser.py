import os
from pathlib import Path
import json,tempfile,mimetypes
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse
root=Path(__file__).resolve().parent
read="""async()=>{const {CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def proof(n,data):log.setdefault('F2:PART-'+str(n).zfill(2),[]).append(data)
allowed={'index.html',*(p.name for p in root.glob('*.mjs') if p.name in {'storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'})}
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'])
 for i in range(12):
  c=b.new_context(viewport={'width':390,'height':844});p=c.new_page();p.set_default_timeout(4500)
  def route(r):
   path=urlparse(r.request.url).path.removeprefix('/');name=path.removeprefix('src/')
   if name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
   else:r.abort()
  c.route('**/*',route)
  def click(label):p.get_by_role('button',name=label,exact=True).click()
  def start():click('整理をはじめる')
  def db():return p.evaluate(read)
  def result():
   start()
   for t in ['次へ','次へ','次へ','結果を見る']:click(t)
  def enter():
   click('詳しく整理する');click('カテゴリを選ぶ');click('このカテゴリを整理')
  def mark(n,**data):log.setdefault('F2:R2INT-'+str(n).zfill(2),[]).append({'category':i,**data})
  p.goto('http://localhost/index.html');start();p.locator('.card').nth(i).get_by_text('使っている',exact=True).click();p.wait_for_selector('.choice.on')
  for t in ['次へ','次へ','次へ','結果を見る']:click(t)
  enter()
  p.locator('.r2-service-grid button').first.click();p.get_by_text('まず利用状態だけ確認',exact=True).wait_for()
  before=db();p.evaluate("""()=>{const put=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(...args){const r=put.apply(this,args);if(this.name==='services'){const tx=this.transaction;r.addEventListener('success',()=>tx.abort());IDBObjectStore.prototype.put=put}return r}}""")
  click('利用中');p.get_by_text('同じ未保存回答を再試行',exact=True).first.wait_for();assert db()==before
  text=p.locator('body').inner_text();assert '未保存' in text;mark(21,old=before['services'][0],pendingMessage=[v for v in text.splitlines() if '未保存' in v][:3])
  click('同じ未保存回答を再試行');p.wait_for_selector('.choice.on:text-is("利用中")');d=db();assert d['globalRevision']==before['globalRevision']+1
  click('いったん詳細整理を終わる');enter();p.locator('.r2-service-grid button').first.click();p.get_by_text('まず利用状態だけ確認',exact=True).wait_for();click('利用中');p.wait_for_selector('.choice.on');click('必要なことだけ確認')
  if p.get_by_role('button',name='次の質問',exact=True).count():click('次の質問')
  click('本人の意向へ');click('この1件を整理完了');click('一覧を見る');d=db();rows=p.locator('.r2-row').all_inner_texts();assert len(rows)==2 and rows[0]==rows[1];assert {r['recordState'] for r in d['services']}=={'completed','partial'}
  p.reload();result();assert db()==d;enter();p.locator('.r2-service-grid button').first.click();p.get_by_text('まず利用状態だけ確認',exact=True).wait_for();click('利用中');p.wait_for_selector('.choice.on');click('必要なことだけ確認')
  if p.get_by_role('button',name='次の質問',exact=True).count():click('次の質問')
  click('本人の意向へ');click('この1件を整理完了');click('一覧を見る');after=p.locator('.r2-row').all_inner_texts();assert len(after)==3 and len(set(after))==1
  if i==0:p.locator('.r2-list').screenshot(path=str(root/'same-state-labels.png'))
  mark(16,rowsAfterReload=after,stored=[{'id':r['recordId'],'state':r['recordState']} for r in db()['services']])
  c.close()
 (root/'fault-browser-results.json').write_text(json.dumps({'version':b.version,'results':log},ensure_ascii=False));print({k:len(v) for k,v in log.items()});b.close()
