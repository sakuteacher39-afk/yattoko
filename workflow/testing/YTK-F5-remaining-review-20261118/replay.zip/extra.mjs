import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import * as C from './canonical.mjs';
import {fixtures,read,parse,cat,newStore,install,snapshot,sign,envelope,fingerprint} from './setup.mjs';
import {IDBFactory} from 'fake-indexeddb';
import {CanonicalStore,openDatabase} from './storage.mjs';
import * as R from './restore.mjs';
import {ReapplySession} from './reapply.mjs';
const out={},add=(group,n,v)=>(out[group+'-'+String(n).padStart(2,'0')]??=[]).push(v),file=id=>JSON.parse(read('fixture-data/'+id+'.json'));
const prior=new Map(JSON.parse(read('old/repeat.json')).map(r=>[r.caseId,r]));
for(const series of [['EM-PENDING-BYTES-',[999999,1000000,1000001],21],['EM-COUNT-',[255,256,257],24]]){
 const [prefix,limits,start]=series;
 for(const [i,v] of limits.entries()){
  const data=file(prefix+v),limit=start===21?fingerprint(data.pending).bytes:data.pending.operations.length;assert.equal(limit,v);
  let observed='accepted';try{await parse(data)}catch(e){observed=e.code??e.message}
  const old=prior.get('F3:R01-'+(start+i));assert.equal(old.status,'MATCH');add('F3:R01',start+i,{fixture:prefix+v,hash:fingerprint(data),layer:limit,expected:i===2?'reject':'accept',observed,capture:old.assertions});
 }
}
for(const fid of ['DS-BASE','DS-MIX']){
 const fac=new IDBFactory(),s=new CanonicalStore(await openDatabase(fac)),other=new CanonicalStore(await openDatabase(fac)),t=await parse(sign(envelope(fixtures[fid])));
 assert.equal(await s.read(),null);let d=await s.save(null,cat('mail','using'));assert.match(d.generationId,/^gen_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
 for(const n of [1,2])add('REG:GEN',n,{fid,generation:d.generationId});
 const old=d;d=await s.save(d,cat('cloud','unknown'));assert.equal(old.generationId,d.generationId);add('REG:GEN',3,{fid,generation:d.generationId});
 const tr=s.db.transaction.bind(s.db);s.db.transaction=(a,m)=>{const tx=tr(a,m);if(m==='readwrite'){const st=tx.objectStore('meta'),put=st.put.bind(st);st.put=v=>{const req=put(v);req.addEventListener('success',()=>tx.abort());return req}}return tx};
 await assert.rejects(s.save(d,{type:'deleteAll'}));assert.deepEqual(await other.read(),d);add('REG:GEN',5,{fid,unchanged:fingerprint(d)});
 const plan=await R.prepareRestore(s,t);await assert.rejects(R.commitRestore(s,plan,{confirmed:true}));assert.deepEqual(await other.read(),d);add('REG:GEN',7,{fid,unchanged:fingerprint(d)});
 s.db.transaction=tr;const deleted=await s.save(d,{type:'deleteAll'});assert.notEqual(deleted.generationId,d.generationId);assert.deepEqual(await other.read(),deleted);add('REG:GEN',4,{fid,before:d.generationId,after:deleted.generationId});
 await install(s,t);const restored=await s.read();assert.notEqual(restored.generationId,fixtures[fid].generationId);assert.notEqual(restored.generationId,deleted.generationId);add('REG:GEN',6,{fid,generation:restored.generationId});
 await assert.rejects(other.save(deleted,cat('social','unknown')),{code:'conflict'});assert.deepEqual(await s.read(),restored);add('REG:GEN',8,{fid,unchanged:fingerprint(restored)});
 const existing=C.id('svc'),candidate=C.id('svc'),newId=C.id('svc');let ids=[existing,candidate,newId];assert.equal(C.generateServiceId([existing],[candidate],()=>ids.shift()),newId);let calls=0;assert.throws(()=>C.generateServiceId([existing],[candidate],()=>{calls++;return candidate}),{code:'collision'});assert.equal(calls,3);add('REG:RID',7,{fid,attempts:calls});
 s.close();other.close();
}
const text=read('restore.mjs'),a=text.indexOf('function replaceTransaction('),b=text.indexOf('export async function commitRestore',a);assert(a>=0&&b>a);const body=text.slice(a,b);assert(!/\b(?:await|async|setTimeout|queueMicrotask)\b|\.then\s*\(/.test(body));add('F3:R03',19,{checked:fingerprint(body),bytes:body.length});
for(const n of [10,24,27,29]){
 const factory=new IDBFactory(),s=new CanonicalStore(await openDatabase(factory)),other=new CanonicalStore(await openDatabase(factory)),mix=fixtures['DS-MIX'];
 await install(s,await parse(sign(envelope(mix))));const d=await s.read(),target=d.services[0],op=n===27?{type:'service',recordId:target.recordId,field:'usageStatus',value:'using'}:n===29?{type:'addService',recordId:C.id('svc'),categoryKey:'mail',serviceCatalogId:'other',otherServiceName:'確認用'}:cat('mail','using');
 const opts={kind:'emergency',pending:[{base:d,operation:op},{base:d,operation:cat('cloud','unknown')}]},backup=await snapshot(s,opts),t=await parse(backup),r=await install(s,t),session=new ReapplySession(s,r),ids=backup.pending.operations.map(x=>x.operationId);
 if(n===10){const copy=newStore();const ss=await copy;await install(ss,await parse(sign(envelope(d))));const d2=await ss.read();const t2=await parse(await snapshot(ss,{...opts,pending:opts.pending.map(it=>({...it,base:d2}))}));await assert.rejects(session.check(t2),{code:'UNPROVEN'});assert.deepEqual(d.categories,d2.categories);ss.close();}
 if(n===24||n===27){if(n===24)await session.apply(t,ids[0],{confirmed:true});const old=await other.read();await other.save(old,n===24?cat('auth','unknown'):{type:'deleteService',recordId:target.recordId});const before=await other.read();await assert.rejects(session.apply(t,ids[n===24?1:0],{confirmed:true}));assert.deepEqual(await other.read(),before);assert.equal(session.status.appliedOperationIds.length,n===24?1:0);}
 if(n===29){await session.apply(t,ids[0],{confirmed:true});const now=await other.read(),child=now.services.find(x=>x.recordId===op.recordId),parent=now.categories.find(x=>x.categoryKey==='mail');assert.equal(child.intentionOverride,null);assert.equal(parent.intention,'unanswered');assert.equal(C.effectiveIntention(child,parent),'undecided');}
 add('F3:R05',n,{snapshot:fingerprint(d),after:fingerprint(await other.read()),status:session.status});s.close();other.close();
}
writeFileSync('extra-results.json',JSON.stringify(out));console.log(Object.entries(out).map(([k,v])=>[k,v[0].observed??'ok']));
