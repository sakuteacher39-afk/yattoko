import os
import json,tempfile
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parent
allowed={'index.html','storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'}
read="""async()=>{const {openDatabase,CanonicalStore}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def mark(case,**v):log.setdefault(case,[]).append(v)
with sync_playwright() as w:
 for apply_first in [False]:
  with tempfile.TemporaryDirectory() as profile:
   def boot():
    ctx=w.chromium.launch_persistent_context(profile,executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'],viewport={'width':390,'height':844})
    def route(r):
     path=urlparse(r.request.url);name=path.path.removeprefix('/').removeprefix('src/')
     if path.netloc=='localhost' and name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
     else:r.abort()
    ctx.route('**/*',route);page=ctx.pages[0];page.set_default_timeout(5000);page.goto('http://localhost/index.html');page.locator('#restore-file').wait_for();return ctx,page
   c,p=boot()
   def loc(v):return p.locator('#'+v)
   def verify():
    loc('restore-file').set_input_files(root/'fixture-data/EM-FULL.json');loc('restore-verify').click();loc('restore-ack').check();expect(loc('restore-commit')).to_be_enabled()
   def db():return p.evaluate(read)
   p.evaluate("""()=>{window.probes=[];for(const name of ['clear','put','getAll']){const prev=IDBObjectStore.prototype[name];IDBObjectStore.prototype[name]=function(...args){const r=prev.apply(this,args);if(this.transaction.mode==='readwrite')r.addEventListener('success',()=>window.probes.push({method:name,store:this.name,save:document.querySelector('#save-status').innerText,restore:document.querySelector('#restore-status').innerText}));return r;}}}""")
   p.get_by_role('button',name='整理をはじめる').click();p.locator('.card').first.get_by_text('わからない',exact=True).click();p.wait_for_selector('.choice.on');trace=p.evaluate('window.probes');puts=[v for v in trace if v['method']=='put'];assert puts and all('端末内に保存済み' not in v['save'] for v in puts);expect(loc('save-status')).to_contain_text('端末内に保存済み');mark('F2:SAVE-01',trace=puts)
   p.reload();p.get_by_role('button',name='整理をはじめる').click()
   for v in ['次へ','次へ','次へ']:p.get_by_role('button',name=v,exact=True).click()
   assert p.locator('.choice.on').inner_text()=='未決定';mark('F2:R07-05',afterReload=db()['categories'][0],display='未決定')
   p.evaluate("""()=>{window.probes=[];for(const name of ['clear','put','getAll']){const prev=IDBObjectStore.prototype[name];IDBObjectStore.prototype[name]=function(...args){const r=prev.apply(this,args);if(this.transaction.mode==='readwrite')r.addEventListener('success',()=>window.probes.push({method:name,store:this.name,restore:document.querySelector('#restore-status').innerText}));return r;}}}""")
   verify();loc('restore-commit').click();expect(loc('reapply-review')).to_be_enabled();after=loc('restore-status').inner_text();tr=p.evaluate('window.probes');assert {'clear','put','getAll'}=={v['method'] for v in tr} and all(v['restore']!=after for v in tr);mark('F3:R03-30',trace=tr,after=after)
   p.evaluate("""async()=>{const {openDatabase}=await import('./src/storage.mjs'),db=await openDatabase();await new Promise((ok,no)=>{const t=db.transaction('meta','readwrite');t.objectStore('meta').put({key:'current',broken:1});t.oncomplete=ok;t.onabort=no});db.close()}""")
   loc('backup-ack').check();p.get_by_role('button',name='通常バックアップを作成').click();expect(loc('backup-status')).to_contain_text('ファイルを作成できませんでした');assert p.get_by_role('button',name='ファイル保存の操作へ進む').is_disabled();verifyButton=loc('restore-verify');loc('restore-file').set_input_files(root/'fixture-data/V-VALID-01.json');verifyButton.click();expect(loc('restore-corrupt-ack')).to_be_visible();mark('F3:R03-06',backup=loc('backup-status').inner_text(),preview=loc('restore-status').inner_text())
   c.close()
(root/'phase-results.json').write_text(json.dumps(log,ensure_ascii=False));print(list(log))
