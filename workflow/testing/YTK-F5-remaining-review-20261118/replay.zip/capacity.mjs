import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {fixtures,read,install,parse,cat,newStore,snapshot,sign,envelope,fingerprint} from './setup.mjs';
import * as C from './canonical.mjs';
import {SaveCoordinator} from './storage.mjs';
import {requestFileSave} from './file-save.mjs';
const out={},add=(group,n,v)=>(out[group+'-'+String(n).padStart(2,'0')]??=[]).push(v),delay=()=>new Promise(r=>setImmediate(r));
const s=await newStore();await install(s,await parse(sign(envelope(fixtures['DS-MIX']))));let d=await s.read();const id=C.id('svc');
await s.save(d,{type:'addService',categoryKey:'subscription',recordId:id,otherServiceName:' e\u0301 ',serviceCatalogId:'other'});d=await s.read();
const p=C.projection(d),size=C.capacity(d);assert.equal(size,fingerprint(p).bytes);assert.deepEqual(p.categories.map(x=>x.categoryKey),C.manifest.categoryKeys);assert.equal(p.categories.length,12);assert(p.categories.some(c=>c.usageStatus==='unanswered'));assert.deepEqual(p.services.map(v=>v.recordId),d.services.map(v=>v.recordId).sort());assert.deepEqual(new Set(p.services.map(x=>x.recordState)),new Set(['partial','completed']));assert(p.services.some(v=>Object.values(v.answers).includes('unanswered')));const rec=p.services.find(v=>v.recordId===id);assert.equal(rec.otherServiceName,'é');assert(!Object.hasOwn(rec.answers,'billingSource'));assert(p.schemaVersion&&p.questionSchemaVersion&&p.generationId&&Number.isInteger(p.globalRevision));assert([p.overview,...p.categories,...p.services].every(v=>v.recordId&&v.schemaVersion&&Number.isInteger(v.revision)));
const reversed=structuredClone(d);reversed.categories.reverse();reversed.services.reverse();assert.deepEqual(C.projection(reversed),p);assert.equal(C.capacity(reversed),size);
const backup=await snapshot(s,{kind:'emergency',pending:[{base:d,operation:cat('mail','using')}]});assert.equal(backup.pending.exportedCount,1);assert.deepEqual(backup.snapshot,p);assert.equal(fingerprint(backup.snapshot).bytes,size);
for(let n=3;n<=13;n++)add('F2:CAP',n,{projection:p,size,withPending:fingerprint(backup.snapshot)});
const serviceOp={type:'service',recordId:id,field:'usageStatus',value:'using'},before=d;
const tr=s.db.transaction.bind(s.db);s.db.transaction=(a,m)=>{const tx=tr(a,m);if(m==='readwrite'){const st=tx.objectStore('services'),put=st.put.bind(st);st.put=v=>{const r=put(v);if(v.recordId===id)r.addEventListener('success',()=>tx.abort());return r}}return tx};
await assert.rejects(s.save(d,serviceOp));assert.deepEqual(await s.read(),before);add('F2:R09',10,{before:fingerprint(before),after:fingerprint(await s.read())});s.db.transaction=tr;
for(const [n,code,error] of [[1,'capacity',new C.SaveError('capacity')],[2,'quota',new DOMException('dummy','QuotaExceededError')],[3,'restricted',new DOMException('dummy','SecurityError')],[4,'conflict',new C.SaveError('conflict')],[5,'temporary',new DOMException('dummy','AbortError')],[9,'conflict',new C.SaveError('conflict')]]){
 const events=[],st=await newStore();await install(st,await parse(sign(envelope(fixtures['DS-MIX']))));const old=await st.read();let calls=0;
 const c=new SaveCoordinator({read:()=>st.read(),save:async(...args)=>{calls++;if(code==='conflict')return st.save({...args[0],globalRevision:args[0].globalRevision-1},args[1]);if(code==='capacity')C.assertCapacity(10000001);throw error}},x=>events.push(x.saved));await c.load();c.submit(cat('mail','using'));while(c.running)await delay();
 assert.equal(c.error,code);assert.equal(c.pending.length,1);assert.deepEqual(await st.read(),old);assert.equal(events.at(-1),false);if(code==='conflict'){assert.throws(()=>c.retry(),{code});assert.equal(calls,1)}
 if(code==='quota')assert(C.messages.quota.includes('可能性'));add('F2:ERR',n,{code,events,calls,unchanged:fingerprint(old)});st.close();
}
assert.equal(C.classify(new DOMException('dummy','QuotaExceededError')),'quota');assert.throws(()=>C.assertCapacity(10000001),{code:'capacity'});add('F2:CAP',18,{browser:'quota',application:'capacity'});
const queue=[],events=[];const coordinator=new SaveCoordinator({read:()=>s.read(),save:(...args)=>new Promise((resolve,reject)=>queue.push(()=>s.save(...args).then(resolve,reject)))},x=>events.push(x.saved));await coordinator.load();coordinator.submit(cat('social','using'));coordinator.submit(cat('cloud','unknown'));assert.equal(events.at(-1),false);await queue.shift()();while(!queue.length)await delay();assert.equal(events.at(-1),false);assert.equal(coordinator.pending.length,1);await queue.shift()();while(coordinator.running)await delay();assert.equal(events.at(-1),true);assert.equal((await s.read()).globalRevision,d.globalRevision+2);for(const n of [2,5])add('F2:SAVE',n,{events,global:(await s.read()).globalRevision});
let attempted=0;await assert.rejects(requestFileSave({bytes:new Uint8Array([1]),filename:'dummy.json'},{Blob:class{constructor(){attempted++;throw Error('injected')}}}),{code:'SAVE_REQUEST_FAILED'});assert.equal(attempted,1);add('F3:R01',27,{attempted,code:'SAVE_REQUEST_FAILED'});
s.close();writeFileSync('capacity-results.json',JSON.stringify(out));console.log(Object.keys(out).length);
