const fs=require('node:fs');
const original=fs.readFileSync;
const mode=process.env.YTK_FAULT;
fs.readFileSync=function(file,...rest){
 const value=original.call(fs,file,...rest),path=String(file);
 if(path.endsWith('canonical-question-manifest-v1.json')&&['enum','key','condition','byte'].includes(mode)){
  if(mode==='byte')return value.replace('"scope"','"Scope"');
  const m=JSON.parse(value);if(mode==='enum')m.r002.questions.device[0].values[1]='changed';if(mode==='key')m.r002.questions.device.pop();if(mode==='condition')m.r002.questions.subscription[1].presence.value='no';return JSON.stringify(m,null,2)+'\n';
 }
 if(path.endsWith('/src/definitions.mjs')&&['missing','extra'].includes(mode)){
  return value.replace(/export const manifest=(.*);\n/,(_,json)=>{
   const m=JSON.parse(json);if(mode==='extra')m.extra=true;else m.r002.questions.device[0].values.pop();return 'export const manifest='+JSON.stringify(m)+';\n';
  });
 }
 return value;
};require('node:module').syncBuiltinESMExports();
