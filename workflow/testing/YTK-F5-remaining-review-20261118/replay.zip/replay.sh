#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
npm ci
prod="$PWD/layout/workflow/prototypes/YTK-F4"
mkdir -p "$prod/src" layout/workflow/{prototypes/{YTK-R001,YTK-R002},proposals,specs}
for f in canonical definitions storage backup backup-ui restore restore-ui import-json import-backup file-save reapply; do ln -sf "$PWD/$f.mjs" "$prod/src/$f.mjs"; done
for f in index.html package.json package-lock.json node_modules F5-F6-TRACEABILITY.json; do ln -sf "$PWD/$f" "$prod/$f"; done
cp generate.mjs "$prod/"
ln -sf "$PWD/r001.html" layout/workflow/prototypes/YTK-R001/prototype.html
ln -sf "$PWD/r002.html" layout/workflow/prototypes/YTK-R002/prototype.html
cp manifest.json layout/workflow/specs/YTK-F4-canonical-question-manifest-v1.json
for f in YTK-*.md; do ln -sf "$PWD/$f" layout/workflow/proposals/; done
(cd "$prod" && sha256sum -c --ignore-missing "$OLDPWD/old/target.sha256" && node generate.mjs --check)
YTK_PRODUCT="$prod" OUT=repeat.json node old/run.mjs
node fixture-files.mjs
for suite in partial service; do JOURNAL="$suite-journal.json" node --import ./journal.mjs "$suite.mjs"; done
for suite in manifest-audit recovery boundaries backups capacity extra limits semantics enums; do node "$suite.mjs"; done
for suite in browser detail resume interaction fault-browser restart errors phase inheritance privacy capture human; do python "$suite.py"; done
node handoff.mjs
for suite in partial service capacity recovery backups boundaries extra semantics; do JOURNAL="$suite-writes.json" node --import ./trace-writes.mjs "$suite.mjs"; done
for suite in browser detail resume interaction fault-browser restart errors phase inheritance privacy capture human; do python browser-observations.py "$suite.py"; done
