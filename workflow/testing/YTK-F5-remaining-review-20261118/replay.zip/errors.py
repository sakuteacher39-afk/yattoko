import os
from pathlib import Path
import json,tempfile,mimetypes
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse
root=Path(__file__).resolve().parent
read="""async()=>{const {CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def proof(n,data):log.setdefault('F2:PART-'+str(n).zfill(2),[]).append(data)
allowed={'index.html',*(p.name for p in root.glob('*.mjs') if p.name in {'storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'})}
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'])
 for code in ['QuotaExceededError','SecurityError','AbortError','OtherFailure','conflict','capacity']:
  c=b.new_context();p=c.new_page();p.set_default_timeout(5000);requests=[];messages=[]
  c.on('request',lambda r:requests.append((r.url,r.post_data)));p.on('console',lambda m:messages.append(m.text));p.on('pageerror',lambda e:messages.append(str(e)))
  def route(r):
   path=urlparse(r.request.url);name=path.path.removeprefix('/').removeprefix('src/')
   if path.netloc=='localhost' and name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
   else:r.abort()
  c.route('**/*',route);p.goto('http://localhost/index.html')
  def btn(label):return p.get_by_role('button',name=label,exact=True)
  def click(label):btn(label).click()
  def mark(case,**v):log.setdefault(case,[]).append({'fault':code,**v})
  click('整理をはじめる');cards=p.locator('.card');cards.first.get_by_text('使っている',exact=True).click();p.wait_for_selector('.choice.on');before=p.evaluate(read)
  p.evaluate("""async code=>{const {SaveError}=await import('./src/canonical.mjs');const put=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(...args){if(this.name==='meta'){IDBObjectStore.prototype.put=put;if(code==='conflict'||code==='capacity')throw new SaveError(code);throw new DOMException('HARNESS_PRIVATE_MARKER',code);}return put.apply(this,args)}}""",code)
  cards.nth(1).get_by_text('わからない',exact=True).click();p.get_by_text('未保存回答を保持しています。再読み込みすると失われる可能性があります。',exact=True).wait_for();assert p.evaluate(read)==before
  status=p.locator('#save-status').inner_text();assert '端末内に保存済み' not in status
  mark('F2:SAVE-03',status=status);mark('F2:ERR-07',status=status,pending=True);assert 'HARNESS_PRIVATE_MARKER' not in status and all('HARNESS_PRIVATE_MARKER' not in m for m in messages)
  mark('F2:ERR-10',status=status,console=messages.copy())
  if code=='OtherFailure':
   assert '原因' in status or '不明' in status;mark('F2:ERR-06',status=status)
  retry=btn('同じ未保存回答を再試行');assert (retry.count()==0)==(code=='conflict');mark('F2:ERR-08',canRetry=bool(retry.count()),status=status)
  if code=='conflict':
   p.evaluate('''async()=>{const {CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());await s.save(await s.read(),{type:'category',categoryKey:'cloud',field:'usageStatus',value:'unknown'});s.close()}''');before=p.evaluate(read)
  p.locator('#backup-ack').check();net=len(requests);click('通常バックアップを作成');bs=p.locator('#backup-status');p.get_by_text('確定済みデータだけ',exact=False).first.wait_for();msg=bs.inner_text();assert '未保存回答・入力中のサービス名は含まれていません' in msg;assert requests[net:]==[];mark('F3:N-08',message=msg);mark('F3:N-10',requestsDuringExport=requests[net:],allURLs=[x[0] for x in requests])
  if code=='conflict':
   click('未保存回答を緊急退避');bs.get_by_text('収録',exact=False).first.wait_for();msg=bs.inner_text();assert '収録 0件' in msg and '未収録 1件' in msg and '未保存回答は退避できませんでした' in msg
   p.evaluate("Object.defineProperty(window,'showSaveFilePicker',{configurable:true,value:undefined})")
   with p.expect_download() as dl:click('ファイル保存の操作へ進む')
   data=json.load(open(dl.value.path()));assert data['pending']['operations']==[] and data['snapshot']==before
   for case in ['F2:BKP-07','F2:BKP-11']:mark(case,message=msg,operations=data['pending']['operations'],omitted=data['pending']['omittedCount'])

  p.evaluate("""()=>{const original=SubtleCrypto.prototype.digest;SubtleCrypto.prototype.digest=function(...args){SubtleCrypto.prototype.digest=original;return Promise.reject(Error('HARNESS_PRIVATE_MARKER'))}}""")
  click('通常バックアップを作成');bs.get_by_text('ファイルを作成できませんでした',exact=False).wait_for();assert btn('ファイル保存の操作へ進む').is_disabled() and p.evaluate(read)==before;mark('F2:BKP-09',message=bs.inner_text(),fileReady=False)
  if code=='conflict':
   dialogs=[]
   def dismiss(d):dialogs.append(d.type);d.dismiss()
   p.once('dialog',dismiss);p.evaluate('()=>setTimeout(()=>location.reload(),0)');p.wait_for_timeout(300);assert dialogs==['beforeunload'] and p.evaluate(read)==before;mark('F3:R01-31',dialogs=dialogs,message=bs.inner_text())
   click('未保存回答を緊急退避');bs.get_by_text('収録',exact=False).first.wait_for();assert '未保存回答を保持' in p.locator('#save-status').inner_text();mark('F3:R01-30',message=bs.inner_text(),pending=p.locator('#save-status').inner_text())
  if code!='conflict':
   click('同じ未保存回答を再試行');p.wait_for_selector('.card:nth-of-type(2) .choice.on');after=p.evaluate(read);assert after['globalRevision']==before['globalRevision']+1
  c.close()
 (root/'error-browser-results.json').write_text(json.dumps({'version':b.version,'results':log},ensure_ascii=False));print(list(log));b.close()
