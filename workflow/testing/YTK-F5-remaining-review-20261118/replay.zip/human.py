import os
import json,tempfile
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parent
allowed={'index.html','storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'}
read="""async()=>{const {openDatabase,CanonicalStore}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def mark(case,**v):log.setdefault(case,[]).append(v)
with sync_playwright() as w:
 for apply_first in [False]:
  with tempfile.TemporaryDirectory() as profile:
   def boot():
    ctx=w.chromium.launch_persistent_context(profile,executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'],viewport={'width':390,'height':844})
    def route(r):
     path=urlparse(r.request.url);name=path.path.removeprefix('/').removeprefix('src/')
     if path.netloc=='localhost' and name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
     else:r.abort()
    ctx.route('**/*',route);page=ctx.pages[0];page.set_default_timeout(5000);page.goto('http://localhost/index.html');page.locator('#restore-file').wait_for();return ctx,page
   c,p=boot()
   def loc(v):return p.locator('#'+v)
   def verify():
    loc('restore-file').set_input_files(root/'fixture-data/EM-FULL.json');loc('restore-verify').click();loc('restore-ack').check();expect(loc('restore-commit')).to_be_enabled()
   def db():return p.evaluate(read)
   p.locator('#backup-panel').screenshot(path=str(root/'backup-notice.png'))
   start=p.locator('#app').inner_text();panel=p.locator('#backup-panel').inner_text();p.get_by_role('button',name='整理をはじめる').click();p.locator('.card').first.get_by_text('使っている',exact=True).click();p.wait_for_selector('.choice.on');get=loc
   get('backup-ack').check();p.get_by_role('button',name='通常バックアップを作成').click();expect(get('backup-status')).to_contain_text('確定済みデータだけ')
   p.evaluate("Object.defineProperty(window,'showSaveFilePicker',{configurable:true,value:undefined})")
   with p.expect_download() as dl:p.get_by_role('button',name='ファイル保存の操作へ進む').click()
   msg=get('backup-status').inner_text();data=json.load(open(dl.value.path()));fileName=dl.value.suggested_filename
   for n in range(1,9):mark('F3:R06-'+str(n).zfill(2),panel=panel,downloadName=fileName,format=data.get('fileFormat'))
   for case in ['F3:N-07','F3:R01-29']:mark(case,message=msg)
   p.evaluate("()=>{URL.createObjectURL=()=>{throw Error('controlled failure')}}")
   p.get_by_role('button',name='ファイル保存の操作へ進む').click();expect(get('backup-status')).to_contain_text('開始できませんでした');mark('F3:R01-28',message=get('backup-status').inner_text())
   for n in range(1,7):mark('F2:LONG-'+str(n).zfill(2),start=start,save=get('save-status').inner_text(),backup=panel)
   mark('F3:R05-37',restorePanel=get('restore-panel').inner_text());c.close()
(root/'human-observations.json').write_text(json.dumps(log,ensure_ascii=False));print(len(log))
