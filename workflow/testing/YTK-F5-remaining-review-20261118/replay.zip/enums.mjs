import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {fixtures,read,fingerprint,parse,sign,envelope} from './setup.mjs';
import * as C from './canonical.mjs';
const M=JSON.parse(read('manifest.json')),log=[],bad=Symbol('absent');
async function check(id,fixture,mutate,shouldPass){const d=structuredClone(fixture);mutate(d);const payload=sign(envelope(d));if(shouldPass){C.validate(d);await parse(payload)}else{assert.throws(()=>C.validate(d));await assert.rejects(parse(payload))}log.push({id,valid:shouldPass,fixture:fingerprint(payload)});}
for(const key of M.categoryKeys){
 const parent=structuredClone(fixtures['DS-BASE']);parent.categories.find(c=>c.categoryKey===key).intention='undecided';
 for(const [field,def] of Object.entries(M.r001.category)){
  for(const v of [...def.values,'invalid-enum',{},bad]){
   const valid=def.values.includes(v);await check(key+':'+field+':'+String(v),parent,d=>{const c=d.categories.find(c=>c.categoryKey===key);if(field==='intention')c.usageStatus='unanswered';if(v===bad)delete c[field];else c[field]=v},valid);
  }
 }
 const base=C.mutate(parent,{type:'addService',categoryKey:key,recordId:'svc_ffffffff-0000-4000-8000-000000000001',serviceCatalogId:'other',otherServiceName:'試験'},parent.generationId);
 for(const [field,def] of Object.entries(M.r002.serviceCore))for(const v of [...def.values,'invalid-enum',{},bad])await check(key+':core:'+field+':'+String(v),base,d=>{const svc=d.services[0];if(field==='recordState')svc.usageStatus='dormant';if(v===bad)delete svc[field];else svc[field]=v},def.values.includes(v));
 for(const q of M.r002.questions[key])for(const v of [...q.values,'invalid-enum',{},bad]){
  await check(key+':'+q.key+':'+String(v),base,d=>{const a=d.services[0].answers;if(q.presence.type==='equals'){a[q.presence.questionKey]=q.presence.value;a[q.key]='unanswered';}if(v===bad)delete a[q.key];else a[q.key]=v;if(key==='subscription'&&q.key==='billing'&&v==='yes')a.billingSource='unanswered';},q.values.includes(v));
 }
}
for(const [field,def] of Object.entries(M.r001.overview))for(const v of [...def.values,'invalid-enum',{},bad])await check(field+':'+String(v),fixtures['DS-BASE'],d=>{if(v===bad)delete d.overview[field];else d.overview[field]=v},def.values.includes(v));
writeFileSync('enum-controls.json',JSON.stringify(log));console.log(log.length)
