import os
from pathlib import Path
import json,tempfile,mimetypes
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse
root=Path(__file__).resolve().parent
read="""async()=>{const {CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def proof(n,data):log.setdefault('F2:PART-'+str(n).zfill(2),[]).append(data)
allowed={'index.html',*(p.name for p in root.glob('*.mjs') if p.name in {'storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'})}
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'])
 for run in range(13):
  i=run if run<12 else 5
  c=b.new_context(viewport={'width':390,'height':844});p=c.new_page();p.set_default_timeout(4500)
  def route(r):
   path=urlparse(r.request.url).path.removeprefix('/');name=path.removeprefix('src/')
   if name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
   else:r.abort()
  c.route('**/*',route)
  def click(label):p.get_by_role('button',name=label,exact=True).click()
  def start():click('整理をはじめる')
  def db():return p.evaluate(read)
  def result():
   start()
   for t in ['次へ','次へ','次へ','結果を見る']:click(t)
  def enter():
   click('詳しく整理する');click('カテゴリを選ぶ');click('このカテゴリを整理')
  def mark(n,**data):log.setdefault('F2:R2INT-'+str(n).zfill(2),[]).append({'category':i,**data})
  p.goto('http://localhost/index.html');start();p.locator('.card').nth(i).get_by_text('使っている',exact=True).click();p.wait_for_selector('.choice.on')
  for t in ['次へ','次へ','次へ','結果を見る']:click(t)
  enter()
  p.locator('.r2-service-grid button').first.click();p.get_by_text('まず利用状態だけ確認',exact=True).wait_for()
  before=db();rec=before['services'][0];assert p.get_by_role('button',name='必要なことだけ確認').is_disabled() and db()==before;mark(102,disabled=True,record=rec)
  assert all(v=='unanswered' for v in rec['answers'].values());mark(9,answers=rec['answers'])
  click('休眠・停止中');p.wait_for_selector('.choice.on');usage=db();p.reload();result();assert db()==usage;mark(7,expected='dormant',record=usage['services'][0]);assert usage['services'][0]['usageStatus']=='dormant'
  enter();p.locator('.r2-service-grid button').first.click();p.get_by_text('まず利用状態だけ確認',exact=True).wait_for();click('わからない');p.wait_for_selector('.choice.on');click('必要なことだけ確認');q=p.locator('.r2-question')
  def target(d):return next(x for x in d['services'] if x['recordId']!=rec['recordId'])
  if run==5:
   assert q.count()==1 and 'billingSource' not in target(db())['answers'];mark(10,answers=target(db())['answers'])
   for j in range(2):
    prev=db();q.first.locator('button').first.click();q.nth(1).wait_for()
    yes=db();assert target(yes)['answers']=={'billing':'yes','billingSource':'unanswered'} and yes['globalRevision']==prev['globalRevision']+1;mark(12,answers=target(yes)['answers'])
    q.nth(1).locator('button').first.click();q.nth(1).locator('.choice.on').wait_for()
    prev=db();q.first.locator('button').nth(1).click();q.nth(1).wait_for(state='detached')
    no=db();assert target(no)['answers']=={'billing':'no'} and no['globalRevision']==prev['globalRevision']+1;mark(11,answers=target(no)['answers'])
  if p.get_by_role('button',name='次の質問',exact=True).count():click('次の質問')
  click('本人の意向へ');click('この1件を整理完了');click('一覧を見る');completed=db();sv=target(completed);assert sv['recordState']=='completed';
  if run!=5:assert all(v=='unanswered' for v in sv['answers'].values());mark(15,record=sv)
  rows=p.locator('.r2-row');texts=rows.all_inner_texts();p.reload();result();assert db()==completed
  enter();p.locator('.r2-service-grid button').first.click();p.get_by_text('まず利用状態だけ確認',exact=True).wait_for()
  click('休眠・停止中');p.wait_for_selector('.choice.on');click('必要なことだけ確認')
  if p.get_by_role('button',name='次の質問',exact=True).count():click('次の質問')
  click('本人の意向へ');click('残したい');p.wait_for_selector('.choice.on:text-is("残したい")');intent=db();r=next(x for x in intent['services'] if x['recordId'] not in [y['recordId'] for y in completed['services']]);assert r['intentionOverride']=='keep';p.reload();result();assert db()==intent;mark(13,record=r)
  c.close()
 (root/'interaction-results.json').write_text(json.dumps({'version':b.version,'results':log},ensure_ascii=False));print({k:len(v) for k,v in log.items()});b.close()
