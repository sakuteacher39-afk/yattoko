import os,json,tempfile
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parent
allowed={'index.html','storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'}
read="""async()=>{const {openDatabase,CanonicalStore}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def mark(case,**v):log.setdefault(case,[]).append({'fixture':fixture,'category':i,**v})
def route(r):
 url=urlparse(r.request.url);name=url.path.strip('/').removeprefix('src/')
 if url.netloc=='localhost' and name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
 else:r.abort()
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.getenv('YTK_CHROMIUM','/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'])
 for fixture in ['DS-MIX']:
  for i in range(1):
   c=b.new_context(viewport={'width':390,'height':844});c.route('**/*',route);p=c.new_page();p.set_default_timeout(5000);p.goto('http://localhost/index.html')
   data=json.load(open(root/('fixture-data/'+fixture+'.json')))
   p.evaluate("""async d=>{const {CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());const {overview,categories,services,...meta}=d;const tx=s.db.transaction(['meta','overview','categories','services'],'readwrite');tx.objectStore('meta').put({key:'current',...meta});tx.objectStore('overview').put(overview);for(const v of categories)tx.objectStore('categories').put(v);for(const v of services)tx.objectStore('services').put(v);await new Promise((ok,no)=>{tx.oncomplete=ok;tx.onabort=no});s.close()}""",data);p.reload()
   def db():return p.evaluate(read)
   assert db()==data
   def btn(t):return p.get_by_role('button',name=t,exact=True)
   def ck(t):btn(t).click()
   def home():
    ck('整理をはじめる')
    for l in ['次へ','次へ','次へ','結果を見る']:ck(l)
   def enter():
    ck('詳しく整理する');ck('カテゴリを選ぶ')
    if btn('ほかのカテゴリも見る').count():ck('ほかのカテゴリも見る')
    p.locator('.card').nth(i).get_by_role('button').click()
   def finish():
    ck('必要なことだけ確認')
    if btn('次の質問').count():ck('次の質問')
    ck('本人の意向へ');ck('この1件を整理完了');ck('一覧を見る')
   def current(d,previous):
    rows=[r for r in d['services'] if r['recordId'] not in {v['recordId'] for v in previous['services']}];assert len(rows)==1;return rows[0]
   home();enter();before=db();ck('その他');assert db()==before;mark('F2:R2INT-03',generation=before['generationId'])
   field=p.locator('input[type=text]');field.fill('   ');p.locator('#backup-ack').check();ck('未保存回答を緊急退避');expect(p.locator('#backup-status')).to_contain_text('未収録 1件');assert field.input_value()=='   ' and db()==before
   mark('F3:R01-04',message=p.locator('#backup-status').inner_text(),originalInputRetained=True);field.fill(' é ');ck('未保存回答を緊急退避');expect(p.locator('#backup-status')).to_contain_text('未収録 0件');assert db()==before;mark('F3:R01-03',message=p.locator('#backup-status').inner_text(),originalInputRetained=field.input_value()==' é ');c.close()
 b.close()
(root/'draft-results.json').write_text(json.dumps(log,ensure_ascii=False));print(list(log))
