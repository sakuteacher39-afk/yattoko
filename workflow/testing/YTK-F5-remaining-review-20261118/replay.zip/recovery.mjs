import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {IDBFactory} from 'fake-indexeddb';
import {fixtures,read,newStore,parse,install,sign,envelope,cat,fingerprint} from './setup.mjs';
import * as C from './canonical.mjs';
import {CanonicalStore,openDatabase} from './storage.mjs';
import * as R from './restore.mjs';
const input=fixtures['DS-MIX'],file=sign(envelope(input)),catalog=JSON.parse(read('FIXTURES.json')).fixtures;
assert.equal(fingerprint(file).sha256,catalog.find(x=>x.id==='V-VALID-01').sha256);
const traceSource=read('old/restore.mjs'),instrument=Function('C','return '+traceSource.slice(traceSource.indexOf('function instrument('),traceSource.indexOf('for(const n of [20,21')))(C);
const proof={},tag=(prefix,n)=>prefix+'-'+String(n).padStart(2,'0');
const record=(prefix,n,data)=>(proof[tag(prefix,n)]??=[]).push(data);
const repeat=JSON.parse(read('old/repeat.json')),previous=new Map(repeat.map(x=>[x.caseId,x]));
for(const n of [20,21,22,23,24,25,26,27,28,29,31,32,33,34,36,37,38,39,40,41,42,43,44,45,47]){
 const fac=new IDBFactory(),s=new CanonicalStore(await openDatabase(fac)),other=new CanonicalStore(await openDatabase(fac));
 await install(s,await parse(file));let old=await other.read();old=await other.save(old,cat('cloud','unknown'));
 const guard=(await R.inspectCurrent(s)).rawGuard,t=await parse(file),p=await R.prepareRestore(s,t),m=instrument(s,n,null),failure=n>=22&&n<=29||n>=34&&n<=38;
 if(failure){
  await assert.rejects(R.commitRestore(s,p,{confirmed:true}));assert(m.fault());m.reset();assert.deepEqual((await R.inspectCurrent(other)).rawGuard,guard);assert.deepEqual(await other.read(),old);
 }else{
  const r=await R.commitRestore(s,p,{confirmed:true});m.reset();const actual=await other.read(),expected={...input,generationId:r.dataset.generationId,globalRevision:1};
  assert.notEqual(expected.generationId,input.generationId);assert.notEqual(expected.generationId,old.generationId);assert.deepEqual(actual,expected);
  if([44,45].includes(n)){await assert.rejects(other.save(old,cat('mail','using')),{code:'conflict'});assert.deepEqual(await s.read(),expected);}
 }
 const id=tag('F3:R03',n);assert.equal(previous.get(id).status,'MATCH');
 record('F3:R03',n,{approvedFile:fingerprint(file),old:fingerprint(old),after:fingerprint(await other.read()),fault:m.fault(),history:m.history,originalAssertions:previous.get(id).assertions});other.close();s.close();
}
for(const fid of ['DS-BASE','DS-MIX']){
 const fixture=fixtures[fid],s=await newStore(),valid=sign(envelope(fixture));
 await install(s,await parse(valid));const before=await s.read(),check=async(n,mutate)=>{
  const body=envelope(structuredClone(fixture));mutate(body);const f=sign(body);await assert.rejects(parse(f));assert.deepEqual(await s.read(),before);record('REG:REG',n,{fid,rejected:fingerprint(f),targetAfter:fingerprint(before)});
 };
 record('REG:REG',1,{fid,accepted:fingerprint(valid)});record('REG:REG',3,{fid,accepted:fingerprint(valid)});
 for(const val of [0,2,'1',null,-1])await check(2,f=>f.fileFormatVersion=val);
 await check(4,f=>f.snapshot.questionSchemaVersion+='x');await check(5,f=>f.snapshot.schemaVersion+='x');
 for(const v of ['old','future'])await check(6,f=>{f.snapshot.questionSchemaVersion=v;f.snapshot.schemaVersion=v});
 for(const n of [1,2]){assert.deepEqual(before.categories.map(c=>c.recordId),C.manifest.categoryKeys.map(k=>'cat_'+k));assert.equal(before.overview.recordId,'ovw_main');record('REG:RID',n,{fid,ids:[before.overview.recordId,...before.categories.map(c=>c.recordId)]});}
 if(fid==='DS-MIX'){
  const checkid=async(n,op)=>{const d=structuredClone(fixture);op(d);await assert.rejects(parse(sign(envelope(d))));assert.deepEqual(await s.read(),before);record('REG:RID',n,{fid,rejected:fingerprint(d)});};
  for(const c of fixture.categories)await checkid(3,d=>d.categories.find(x=>x.categoryKey===c.categoryKey).recordId='cat_incorrect');
  for(const svc of before.services)assert.match(svc.recordId,/^svc_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
  record('REG:RID',4,{ids:before.services.map(r=>r.recordId)});
  for(const v of ['svc_AAAAAAAA-0000-4000-8000-000000000001','{'+before.services[0].recordId+'}',...['1','7'].map(k=>before.services[0].recordId.replace('-4000','-'+k+'000')),before.services[0].recordId.replace('-8000','-0000'),before.services[0].recordId.replace('svc','svx')])await checkid(5,d=>d.services[0].recordId=v);
  await checkid(6,d=>d.services[1].recordId=d.services[0].recordId);
  for(const svc of before.services){await assert.rejects(s.save(before,{type:'service',recordId:svc.recordId,field:'recordId',value:'changed'}));assert.deepEqual(await s.read(),before);}record('REG:RID',8,{fid,unchanged:fingerprint(before)});
 }
 s.close();
}
writeFileSync('recovery-results.json',JSON.stringify(proof));console.log(Object.keys(proof).length);
