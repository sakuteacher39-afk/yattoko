import vm from 'node:vm';
import {mkdirSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {read,digest} from './setup.mjs';
const catalog=JSON.parse(read('FIXTURES.json')).fixtures,src=read('prepare-fixtures.mjs'),out='fixture-data';
mkdirSync(out,{recursive:true});
const code=src.slice(src.indexOf('const schema='),src.indexOf('for(const size of [15_999_999'));
vm.runInNewContext(code,{Buffer,structuredClone,path,out,M:JSON.parse(read('manifest.json')),hash:digest,encode:o=>Buffer.from(JSON.stringify(o)),writeFileSync:(p,b)=>{const name=path.basename(p,'.json'),e=catalog.find(x=>x.id===name);assert.equal(b.length,e.bytes);assert.equal(digest(b),e.sha256);writeFileSync(p,b)}});
