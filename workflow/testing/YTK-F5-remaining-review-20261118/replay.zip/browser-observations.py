from pathlib import Path
import ast,gzip,hashlib,json,sys
root=Path(__file__).resolve().parent
out=root/'browser-traces';out.mkdir(exist_ok=True)
suite=Path(sys.argv[1]);module=ast.parse(suite.read_text());path=out/(suite.stem+'.jsonl.gz')
def observe(page,case):
 data=page.evaluate("""async()=>{const {openDatabase}=await import('./src/storage.mjs');const db=await openDatabase();try{const names=[...db.objectStoreNames];const raw=await new Promise((ok,no)=>{const t=db.transaction(names,'readonly'),v={};for(const n of names){const r=t.objectStore(n).getAll();r.onsuccess=()=>v[n]=r.result}t.oncomplete=()=>ok(v);t.onabort=no});return {dom:document.body.innerText,raw,origin:location.origin}}finally{db.close()}}""")
 raw=json.dumps(data.pop('raw'),ensure_ascii=False,separators=(',',':')).encode()
 data.update(case=case,rawBytes=len(raw),rawSHA256=hashlib.sha256(raw).hexdigest(),browser=page.evaluate('navigator.userAgent'))
 stream.write((json.dumps(data,ensure_ascii=False)+'\n').encode())
for fn in ast.walk(module):
 if not isinstance(fn,ast.FunctionDef) or fn.name not in ['mark','proof']:continue
 name=fn.args.args[0].arg
 fn.body.insert(0,ast.parse('observe(p,'+name+')').body[0])
ast.fix_missing_locations(module)
with gzip.open(path,'wb') as stream:exec(compile(module,str(suite),'exec'),{'__file__':str(suite.resolve()),'__name__':'__main__','observe':observe})
