import os
from pathlib import Path
import json,tempfile,mimetypes
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse
root=Path(__file__).resolve().parent
read="""async()=>{const {CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def proof(n,data):log.setdefault('F2:PART-'+str(n).zfill(2),[]).append(data)
allowed={'index.html',*(p.name for p in root.glob('*.mjs') if p.name in {'storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'})}
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'])
 for i in range(12):
  c=b.new_context(viewport={'width':390,'height':844});p=c.new_page();p.set_default_timeout(4500)
  def route(r):
   path=urlparse(r.request.url).path.removeprefix('/');name=path.removeprefix('src/')
   if name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
   else:r.abort()
  c.route('**/*',route)
  def click(label):p.get_by_role('button',name=label,exact=True).click()
  def start():click('整理をはじめる')
  def db():return p.evaluate(read)
  def result():
   start()
   for t in ['次へ','次へ','次へ','結果を見る']:click(t)
  def enter():
   click('詳しく整理する');click('カテゴリを選ぶ');click('このカテゴリを整理')
  def mark(n,**data):log.setdefault('F2:R2INT-'+str(n).zfill(2),[]).append({'category':i,**data})
  p.goto('http://localhost/index.html');start();p.locator('.card').nth(i).get_by_text('使っている',exact=True).click();p.wait_for_selector('.choice.on')
  for t in ['次へ','次へ','次へ','結果を見る']:click(t)
  enter()
  click('その他');empty=db();assert len(empty['services'])==0;mark(3,revision=empty['globalRevision'])
  p.locator('input[type=text]').fill('試験サービス');assert db()==empty;mark(4,text='試験サービス',records=0)
  click('利用状態へ');p.get_by_text('まず利用状態だけ確認',exact=True).wait_for();added=db();assert len(added['services'])==1 and added['services'][0]['recordState']=='partial' and added['services'][0]['otherServiceName']=='試験サービス';mark(5,record=added['services'][0])
  click('いったん詳細整理を終わる');assert db()==added;mark(20,globalRevision=added['globalRevision'])
  enter();p.locator('.r2-service-grid button').first.click();p.get_by_text('まず利用状態だけ確認',exact=True).wait_for()
  known=next(r for r in db()['services'] if r['recordId']!=added['services'][0]['recordId']);assert known['recordState']=='partial' and known['serviceCatalogId']!='other';mark(1,record=known)
  click('休眠・停止中');p.wait_for_selector('.choice.on');click('必要なことだけ確認')
  questions=p.locator('.r2-question');first=questions.first.locator('button').last;label=first.inner_text();first.click();p.wait_for_selector('.choice.on')
  if p.get_by_role('button',name='次の質問',exact=True).count():click('次の質問')
  click('本人の意向へ');click('残したい');p.wait_for_selector('.choice.on:text-is("残したい")');click('この1件を整理完了');click('一覧を見る')
  data=db();rows=p.locator('.r2-row');assert rows.count()==2
  rec=next(x for x in data['services'] if x['recordId']==known['recordId']);assert rec['recordState']=='completed';mark(14,record=rec)
  uirows=rows.all_inner_texts();mark(16,rows=uirows,states=[v['recordState'] for v in data['services']],statusLabelsVisible=all(any(label in t for label in ['途中','未完了','完了済','整理完了']) for t in uirows))
  rows.filter(has_text=known['serviceCatalogId']).get_by_role('button').click();assert db()==data;mark(17,revision=rec['revision'])
  click('利用中');p.wait_for_selector('.choice.on:text-is("利用中")');edited=db();new=next(x for x in edited['services'] if x['recordId']==rec['recordId']);assert new['recordState']=='partial' and new['revision']==rec['revision']+1 and edited['globalRevision']==data['globalRevision']+1;mark(18,record=new)
  click('必要なことだけ確認')
  if p.get_by_role('button',name='次の質問',exact=True).count():click('次の質問')
  click('本人の意向へ');click('この1件を整理完了');click('一覧を見る');completed=db();assert next(x for x in completed['services'] if x['recordId']==rec['recordId'])['recordState']=='completed';mark(19,globalRevision=completed['globalRevision'])
  p.reload();result();enter();assert db()==completed
  mark(2,availableButtons=p.locator('#app button').all_inner_texts(),persisted=True)
  (root/'detail-results.json').write_text(json.dumps({'version':b.version,'results':log},ensure_ascii=False))
  c.close()
 print({k:len(v) for k,v in log.items()});b.close()
