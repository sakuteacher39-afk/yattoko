import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {fixtures,read,fingerprint} from './setup.mjs';
import {registry,manifest,validate} from './canonical.mjs';
const root=resolve('layout/workflow/prototypes/YTK-F4'),norm=JSON.parse(read('manifest.json'));
validate(fixtures['DS-BASE']);assert.deepEqual(manifest,norm);
const old=JSON.parse(read('old/repeat.json')),proof={};
const controls={};
for(const mode of ['none','enum','key','condition','byte','missing','extra']){
 const r=spawnSync(process.execPath,['--require',resolve('drift.cjs'),'generate.mjs','--check'],{cwd:root,env:{...process.env,YTK_FAULT:mode},encoding:'utf8'});
 const msg=mode==='none'?null:['missing','extra'].includes(mode)?'Generated definitions drift':'Unapproved manifest drift';
 assert.equal(r.status,mode==='none'?0:1);if(msg)assert(r.stderr.includes('Error: '+msg));controls[mode]={expected:msg,status:r.status,observed:r.stderr.match(/^Error: .*$/m)?.[0]??null};
}
const blob=spawnSync('git',['hash-object','manifest.json'],{encoding:'utf8'}).stdout.trim();assert.equal(registry.questionSchemaVersion,'ytk-qm-gitblob-'+blob);
for(const item of old){
 const [group,num]=item.caseId.split('-'),n=+num;
 if(!(group==='F3:MAN'&&((n>=1&&n<=30)||[34,35,38].includes(n))||group==='REG:MAN'&&[2,3,4,5,7,8,9,10].includes(n)))continue;
 assert.equal(item.status,'MATCH');assert(item.assertions.length);
 proof[item.caseId]={assertions:item.assertions,controls,manifestBlob:blob,fixture:fingerprint(fixtures['DS-BASE'])};
}
writeFileSync('manifest-results.json',JSON.stringify(proof));console.log(Object.keys(proof).length);
