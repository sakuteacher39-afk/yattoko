import assert from 'node:assert/strict';
import vm from 'node:vm';
import {writeFileSync} from 'node:fs';
import {fixtures,read,fingerprint,newStore,envelope,sign,parse,install} from './setup.mjs';
const recipe=read('prepare-fixtures.mjs'),M=JSON.parse(read('manifest.json'));
vm.runInNewContext(recipe.slice(recipe.indexOf('const schema='),recipe.indexOf('const body='))+recipe.slice(recipe.indexOf('const cond=base();'),recipe.indexOf('const valid=')),{M,save:(id,v)=>fixtures[id]=structuredClone(v)});
const log={},expected=JSON.parse(read('FIXTURES.json')).fixtures;
for(const fid of ['DS-MIX','DS-CONDITIONAL']){
 const fixture=fixtures[fid];assert.equal(fingerprint(fixture).sha256,expected.find(x=>x.id===fid).sha256);
 for(const key of M.categoryKeys){
  const s=await newStore();const token=o=>parse(sign(envelope(o)));
  await install(s,await token(fixture));let d=await s.read();
  const id='svc_ffffffff-0000-4000-8000-000000000099';
  const save=async op=>{await s.save(d,op);d=await s.read()};
  const op=(field,value)=>({type:'service',recordId:id,field,value});
  const complete={type:'completeService',recordId:id};
  const row=()=>d.services.find(r=>r.recordId===id);
  const observe=(n,extras={})=>(log['F2:R08-'+String(n).padStart(2,'0')]??=[]).push({fid,key,state:row().recordState,usage:row().usageStatus,after:fingerprint(d),...extras});
  await save({type:'addService',categoryKey:key,recordId:id,serviceCatalogId:'other',otherServiceName:'試験用'});
  for(const [n,v] of [[1,'unanswered'],[3,'using'],[4,'dormant'],[5,'unknown']]){
   if(n!==1){await save(op('usageStatus',v));await save(complete);}
   assert.equal(row().recordState,n===1?'partial':'completed');assert.equal(row().usageStatus,v);
   const rr=await newStore();await install(rr,await token(d));const r=await rr.read();assert.deepEqual(r.services,d.services);rr.close();observe(n,{restoredServices:fingerprint(r.services)});
   if(n===1){await assert.rejects(s.save(d,complete));assert.deepEqual(await s.read(),d);observe(2);}
  }
  for(const value of ['keep','delete','family','undecided',null]){await save(op('intentionOverride',value));assert.equal(row().intentionOverride,value);await token(d);observe(13,{value,accepted:true})}
  for(const value of ['unknown','unanswered','',1,false,{},[]]){
   await assert.rejects(s.save(d,op('intentionOverride',value)));assert.deepEqual(await s.read(),d);
   const bad=structuredClone(d);bad.services.find(r=>r.recordId===id).intentionOverride=value;await assert.rejects(token(bad));observe(13,{value,accepted:false});
  }s.close();
 }
}
writeFileSync('service-results.json',JSON.stringify(log));console.log(Object.keys(log));
