import os
from pathlib import Path
import json,tempfile,mimetypes
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse
root=Path(__file__).resolve().parent
read="""async()=>{const {CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def proof(n,data):log.setdefault('F2:PART-'+str(n).zfill(2),[]).append(data)
allowed={'index.html',*(p.name for p in root.glob('*.mjs') if p.name in {'storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'})}
with sync_playwright() as w:
 b=w.chromium.launch(executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'])
 for i in range(12):
  c=b.new_context(viewport={'width':390,'height':844});p=c.new_page();p.set_default_timeout(4500)
  def route(r):
   path=urlparse(r.request.url).path.removeprefix('/');name=path.removeprefix('src/')
   if name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
   else:r.abort()
  c.route('**/*',route)
  def click(label):p.get_by_role('button',name=label,exact=True).click()
  def start():click('整理をはじめる')
  def db():return p.evaluate(read)
  def result():
   start()
   for t in ['次へ','次へ','次へ','結果を見る']:click(t)
  def enter():
   click('詳しく整理する');click('カテゴリを選ぶ');click('このカテゴリを整理')
  def mark(n,**data):log.setdefault('F2:R2INT-'+str(n).zfill(2),[]).append({'category':i,**data})
  p.goto('http://localhost/index.html');start();p.locator('.card').nth(i).get_by_text('使っている',exact=True).click();p.wait_for_selector('.choice.on')
  for t in ['次へ','次へ','次へ','結果を見る']:click(t)
  enter()
  if i%2:
   click('その他');p.locator('input[type=text]').fill('再開検証');click('利用状態へ')
  else:p.locator('.r2-service-grid button').first.click()
  p.get_by_text('まず利用状態だけ確認',exact=True).wait_for();before=db();row=before['services'][0];assert row['recordState']=='partial'
  def reload_to_result():p.reload();result();assert before==db()
  reload_to_result();buttons={'result':p.locator('#app button').all_inner_texts()}
  click('詳しく整理する');buttons['entry']=p.locator('#app button').all_inner_texts();click('カテゴリを選ぶ');buttons['category']=p.locator('#app button').all_inner_texts();click('このカテゴリを整理');buttons['services']=p.locator('#app button').all_inner_texts()
  if i%2:
   click('その他');p.locator('input[type=text]').fill('再開検証');click('利用状態へ')
  else:p.get_by_role('button',name=row['serviceCatalogId'],exact=True).click()
  p.get_by_text('まず利用状態だけ確認',exact=True).wait_for();again=db();assert len(again['services'])==2 and again['services'][0]['recordId']!=again['services'][1]['recordId']
  mark(6 if i%2 else 2,beforeId=row['recordId'],afterIds=[v['recordId'] for v in again['services']],buttons=buttons)
  click('わからない');p.wait_for_selector('.choice.on');click('必要なことだけ確認')
  qs=p.locator('.r2-question');q=qs.first;buttons=q.locator('.choice')
  buttons.last.click();p.wait_for_selector('.r2-question .choice.on');d=db();current=next(v for v in d['services'] if v['recordId']!=row['recordId'])
  p.reload();result();assert db()==d;mark(7,record=current);mark(8,record=current)
  c.close()
 (root/'resume-results.json').write_text(json.dumps({'version':b.version,'results':log},ensure_ascii=False));print({k:len(v) for k,v in log.items()});b.close()
