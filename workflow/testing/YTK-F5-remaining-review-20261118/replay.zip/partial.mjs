import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {fixtures,newStore,cat,fingerprint,read} from './setup.mjs';
const manifest=JSON.parse(read('manifest.json'));
const log={};
const proof=(n,value)=>(log['F2:PART-'+String(n).padStart(2,'0')]??=[]).push(value);
function monitor(db,abortAt){
 const tx=db.transaction.bind(db),events=[];
 db.transaction=(...args)=>{
  const t=tx(...args);
  if(args[1]!=='readwrite')return t;
  const e={puts:0,stores:[...t.objectStoreNames]};events.push(e);
  const store=t.objectStore.bind(t),seen=new Set();
  t.objectStore=name=>{
   const s=store(name);
   if(!seen.has(s)){seen.add(s);const put=s.put.bind(s);s.put=v=>{
    const r=put(v);const position=++e.puts;
    if(position===abortAt)r.addEventListener('success',()=>t.abort());return r;
   };}return s;
  };
  for(const type of ['complete','abort'])t.addEventListener(type,()=>e.end=type);
  return t;
 };
 return events;
}
for(const key of manifest.categoryKeys){
 for(const value of manifest.r001.category.usageStatus.values.slice(1)){
  const s=await newStore(),events=monitor(s.db),op=cat(key,value);
  assert.equal(await s.read(),null);
  await s.save(null,op);let d=await s.read();const target=d.categories.find(c=>c.categoryKey===key);
  assert.equal(events.length,1);assert.equal(events[0].end,'complete');assert.equal(events[0].puts,14);
  assert.equal(target.usageStatus,value);assert.equal(target.revision,1);assert.equal(d.globalRevision,1);
  assert.equal(d.categories.length,12);
  assert(d.categories.filter(c=>c!==target).every(c=>c.usageStatus==='unanswered'&&c.intention==='unanswered'&&c.revision===0));
  assert.equal(d.overview.revision,0);for(const k of Object.keys(manifest.r001.overview))assert.equal(d.overview[k],'unanswered');
  const observed={op,events:structuredClone(events),global:d.globalRevision,stored:fingerprint(d)};
  for(const n of [2,3,4,...(value==='unknown'?[7]:[])])proof(n,observed);
  for(const [field,values] of Object.entries(manifest.r001.category)){
   for(const v of values.values.slice(1)){
    const old=d,c=d.categories.find(c=>c.categoryKey===key);if(c[field]===v)continue;
    await s.save(d,{...op,field,value:v});d=await s.read();const row=d.categories.find(c=>c.categoryKey===key);
    assert.equal(row[field],v);assert.equal(row.revision,c.revision+1);assert.equal(d.globalRevision,old.globalRevision+1);
    assert.deepEqual(d.categories.filter(x=>x!==row),old.categories.filter(x=>x!==c));assert.deepEqual(d.overview,old.overview);
    proof(9,{key,field,value:v,revision:row.revision,global:d.globalRevision});
   }
  }
  s.close();
 }
 const s=await newStore();await s.save(null,{...cat(key),field:'intention',value:'undecided'});const d=await s.read();
 assert.equal(d.categories.find(c=>c.categoryKey===key).intention,'undecided');assert(d.categories.filter(c=>c.categoryKey!==key).every(c=>c.intention==='unanswered'));
 proof(8,{key,stored:fingerprint(d)});s.close();
}
for(const pos of [1,7,14]){
 const s=await newStore(),events=monitor(s.db,pos);
 await assert.rejects(s.save(null,cat('device','using')),{name:'AbortError'});assert.equal(await s.read(),null);assert.equal(events[0].end,'abort');proof(2,{pos,events,after:null});s.close();
}
for(const [field,def] of Object.entries(manifest.r001.overview)){
 const s=await newStore();let d=null;
 for(const value of [...def.values.slice(1),'unanswered']){
  const before=d,op={type:'overview',field,value};await s.save(d,op);d=await s.read();
  assert.equal(d.overview[field],value);assert.equal(d.overview.revision,(before?.overview.revision??0)+1);assert.equal(d.globalRevision,(before?.globalRevision??0)+1);
  assert.deepEqual(d.categories,before?.categories??fixtures['DS-BASE'].categories.map(c=>({...c,usageStatus:'unanswered',intention:'unanswered',revision:0})));
  for(const key of Object.keys(manifest.r001.overview).filter(k=>k!==field))assert.equal(d.overview[key],before?.overview[key]??'unanswered');
  proof(10,{op,revision:d.overview.revision,global:d.globalRevision});
 }s.close();
}
writeFileSync('partial-results.json',JSON.stringify(log));console.log(Object.keys(log));
