import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {read,parse,sign,fingerprint} from './setup.mjs';
const sources=[JSON.parse(read('fixture-data/V-VALID-01.json')),JSON.parse(read('fixture-data/EM-FULL.json'))];
const cases=[['root',0,[]],['meta',0,['snapshot']],['overview',0,['snapshot','overview']],['category',0,['snapshot','categories',0]],['service',0,['snapshot','services',0]],['answers',0,['snapshot','services',0,'answers']],['pending',1,['pending']],['operation',1,['pending','operations',0]],['context',1,['pending','operations',0,'dependencyContext']],['checksum',1,['checksum']]],out=[];
for(const [level,idx,path] of cases){const source=sources[idx];await parse(source);
 for(const key of ['remove-required','unexpected','__proto__','constructor','prototype']){
  const changed=structuredClone(source),part=path.reduce((a,k)=>a[k],changed);if(key==='remove-required')delete part[Object.keys(part)[0]];else Object.defineProperty(part,key,{value:'inert-marker',enumerable:true});
  const {checksum,...body}=changed;
  for(const mode of level==='checksum'?['checksum-field']:['stale','resigned']){const f=mode==='resigned'?sign(body):changed;let code;try{await parse(f)}catch(e){code=e.code}assert(code);out.push({level,key,mode,code,input:fingerprint(f)});}
 }
}
writeFileSync('field-controls.json',JSON.stringify(out));console.log(out.length);
