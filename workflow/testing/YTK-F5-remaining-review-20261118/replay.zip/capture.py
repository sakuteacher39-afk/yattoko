import os
import json,tempfile
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parent
allowed={'index.html','storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'}
read="""async()=>{const {openDatabase,CanonicalStore}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def mark(case,**v):log.setdefault(case,[]).append(v)
with sync_playwright() as w:
 for apply_first in [False]:
  with tempfile.TemporaryDirectory() as profile:
   def boot():
    ctx=w.chromium.launch_persistent_context(profile,executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'],viewport={'width':390,'height':844})
    def route(r):
     path=urlparse(r.request.url);name=path.path.removeprefix('/').removeprefix('src/')
     if path.netloc=='localhost' and name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
     else:r.abort()
    ctx.route('**/*',route);page=ctx.pages[0];page.set_default_timeout(5000);page.goto('http://localhost/index.html');page.locator('#restore-file').wait_for();return ctx,page
   c,p=boot()
   def loc(v):return p.locator('#'+v)
   def verify():
    loc('restore-file').set_input_files(root/'fixture-data/EM-FULL.json');loc('restore-verify').click();loc('restore-ack').check();expect(loc('restore-commit')).to_be_enabled()
   def db():return p.evaluate(read)
   data=p.evaluate("""async base=>{
    const {installBackupUI}=await import('./src/backup-ui.mjs');const {createBackup}=await import('./src/backup.mjs');const {requestFileSave}=await import('./src/file-save.mjs');
    const doc=document.implementation.createHTMLDocument(),app=doc.createElement('div');app.id='app';doc.body.append(app);const keys=base.categories.map(c=>c.categoryKey);
    const pending=Array.from({length:257},(_,i)=>({base,operation:{type:'category',categoryKey:keys[i%12],field:'usageStatus',value:Math.floor(i/12)%2?'unknown':'not_using'}}));const capture={pending},orig=JSON.stringify(capture);let prepared;
    installBackupUI(doc,{getStore:()=>({read:async()=>base}),getCapture:()=>capture,create:async(...args)=>{prepared=await createBackup(...args);return prepared},save:artifact=>requestFileSave(artifact,{Blob:class{constructor(){throw Error('injected')}}})});
    const byText=t=>[...doc.querySelectorAll('button')].find(b=>b.textContent===t);doc.querySelector('#backup-ack').click();byText('未保存回答を緊急退避').click();
    const until=async fn=>{const end=Date.now()+15000;while(!fn()){if(Date.now()>end)throw Error('timeout');await new Promise(r=>setTimeout(r,10));}};
    await until(()=>!byText('ファイル保存の操作へ進む').disabled);const msg=doc.querySelector('#backup-status').textContent;
    byText('ファイル保存の操作へ進む').click();await until(()=>doc.querySelector('#backup-status').textContent.includes('開始できませんでした'));return {unchanged:orig===JSON.stringify(capture),candidate:prepared.summary.candidateCount,exported:prepared.summary.exportedCount,omitted:prepared.summary.omittedCount,summary:msg,failed:doc.querySelector('#backup-status').textContent};
   }""",json.load(open(root/'fixture-data/DS-BASE.json')))
   assert data['unchanged'] and [data['candidate'],data['exported'],data['omitted']]==[257,0,257] and '未収録 257件' in data['summary'];mark('F3:R01-26',**data);assert '退避は確認できていません' in data['failed'];mark('F3:R01-27',**data);c.close()
(root/'capture-results.json').write_text(json.dumps(log,ensure_ascii=False));print(list(log))
