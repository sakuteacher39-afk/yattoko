import assert from 'node:assert/strict';
import {writeFileSync,mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {fixtures,read,newStore,install,parse,sign,envelope,snapshot,fingerprint} from './setup.mjs';
import * as C from './canonical.mjs';
const M=JSON.parse(read('manifest.json')),norm=read('norm-f2.md'),out={};
const enums=s=>Array.from(s.matchAll(/\["([a-z_]+)",/g),x=>x[1]);
for(const name of ['index.html','r001.html']){
 const html=read(name),matches=Array.from(html.matchAll(/p.appendChild\(quickQuestion\([^\n]*?,"([a-z]+)",(\[\[.*?\]\])\)\)/g));
 assert.deepEqual(Object.fromEntries(matches.map(m=>[m[1],['unanswered',...enums(m[2])]])),Object.fromEntries(Object.entries(M.r001.overview).map(([k,v])=>[k,v.values])));
 for(const [field,first] of [['usageStatus','using'],['intention','keep']]){const match=html.match(new RegExp('\\[\\["'+first+'",.*?\\]\\]\\.forEach'));assert.deepEqual(['unanswered',...enums(match[0])],M.r001.category[field].values);}
}
out['F3:MAN-33']={approved:fingerprint(read('r001.html')),current:fingerprint(read('index.html')),r001:M.r001};
const positive=[['billing=yes','billing: no -> yes','billing','yes','r001.overview.billing'],['finance系 asset=yes','finance: no -> yes','asset','yes','r001.overview.finance'],['importantData=yes','data: no -> yes','importantData','yes','r001.overview.data'],['familyKnow=no','family: known -> hidden','familyKnow','no','r001.overview.family']];
for(const [a,b,key,when,target] of positive){assert(norm.split('\n').some(l=>l.includes(a)&&l.includes(b)));assert(M.validatorBindings.positiveDirection.some(x=>x.sourceQuestionKey===key&&x.when===when&&x.target===target));}
for(const k of ['F2-R07','F2-R08','F2-R09']){assert(norm.includes(k));assert(M.validatorBindings[k.replace('-','_')]);}
const qr=C.manifest.r002.questions.subscription[1];assert.deepEqual(qr.presence,{type:'equals',questionKey:'billing',value:'yes'});assert.deepEqual(C.manifest,M);
for(const id of ['F3:MAN-36','REG:MAN-06'])out[id]={normative:fingerprint(norm),positive,presence:M.presenceRules,bindings:M.validatorBindings,behaviorEvidence:['manifest-results.json','service-results.json','boundary-results.json','interaction-results.json']};
assert.deepEqual(Object.keys(M),['manifestFormatVersion','scope','categoryKeys','r001','r002','presenceRules','validatorBindings']);assert.equal(M.manifestFormatVersion,1);assert.equal(M.categoryKeys.length,12);assert.equal(new Set(M.categoryKeys).size,12);let count=0;
for(const key of M.categoryKeys){for(const q of M.r002.questions[key]){assert.equal(typeof q.key,'string');assert(q.values.every(v=>typeof v==='string'));assert.equal(new Set(q.values).size,q.values.length);assert(q.values.includes('unanswered'));assert(['always','equals'].includes(q.presence.type));count++;}}
assert.equal(count,33);out['REG:MAN-01']={schema:M.manifestFormatVersion,categories:M.categoryKeys.length,questions:count,source:fingerprint(M)};
const dir=mkdtempSync(join(tmpdir(),'ytk-validator-'));try{
 const source=read('canonical.mjs'),anchor='if(active(q,s.answers))member(s.answers[q.key],q);';assert(source.includes(anchor));const substituted=source.replace(anchor,"if(active(q,s.answers))member(s.answers[q.key],q.key==='importantData'?{values:['unanswered']}:q);");
 writeFileSync(join(dir,'canonical.mjs'),substituted);writeFileSync(join(dir,'definitions.mjs'),read('definitions.mjs'));const negative=await import(pathToFileURL(join(dir,'canonical.mjs')));
 const d=structuredClone(fixtures['DS-MIX']);d.services[0].answers.importantData='yes';d.overview.data='yes';C.validate(d);assert.throws(()=>negative.validate(d));out['F3:MAN-31']={control:'accepted',alteredValidator:'rejected',fixture:fingerprint(d),source:fingerprint(source)};
}finally{rmSync(dir,{recursive:true})}
const s=await newStore();await install(s,await parse(sign(envelope(fixtures['DS-MIX']))));const before=await s.read();const inputs=['😀'.repeat(30),'😀'.repeat(30)+'a','😀'.repeat(31),' e\u0301 ','   '];
for(const input of inputs){const expected=input.normalize('NFC').trim(),valid=expected.length>0&&expected.length<=60,op={type:'addService',categoryKey:'mail',recordId:C.id('svc'),serviceCatalogId:'other',otherServiceName:input};const base=await s.read();const em=await snapshot(s,{kind:'emergency',draft:{categoryKey:'mail',otherServiceName:input},draftBase:base});const bad=structuredClone(base);bad.services[0].otherServiceName=input;
 if(valid){await s.save(base,op);const d=await s.read();assert.equal(d.services.find(r=>r.recordId===op.recordId).otherServiceName,expected);const t=await parse(await snapshot(s));const ss=await newStore();await install(ss,t);assert.deepEqual((await ss.read()).services,d.services);ss.close();assert.equal(em.pending.operations[0].canonicalValue.otherServiceName,expected);}
 else{await assert.rejects(s.save(base,op));assert.deepEqual(await s.read(),base);assert.equal(em.pending.exportedCount,0);}
 if(!valid||expected!==input)await assert.rejects(parse(sign(envelope(bad))));
 (out['F2:TXT-15']??=[]).push({inputUnits:input.length,normalizedUnits:expected.length,valid,exported:em.pending.exportedCount});
}
assert(/maxLength\s*=\s*60/.test(read('r002.html'))&&/maxLength\s*=\s*60/.test(read('index.html')));out['F2:TXT-14']={uiLimit:60,tested:out['F2:TXT-15']};s.close();
writeFileSync('semantics-results.json',JSON.stringify(out));console.log(Object.keys(out));
