import {IDBDatabase} from 'fake-indexeddb';
import {writeFileSync} from 'node:fs';
import {fingerprint} from './setup.mjs';
const original=IDBDatabase.prototype.transaction,rows=[];
function sample(db){
 return new Promise((resolve,reject)=>{let t;try{t=original.call(db,[...db.objectStoreNames],'readonly')}catch(e){reject(e);return}
 const data={};for(const name of t.objectStoreNames){const req=t.objectStore(name).getAll();req.onsuccess=()=>data[name]=req.result}
 t.oncomplete=()=>resolve({raw:fingerprint(data),stores:Object.fromEntries(Object.entries(data).map(([k,v])=>[k,v.length])),generation:data.meta?.[0]?.generationId,global:data.meta?.[0]?.globalRevision});t.onabort=()=>reject(t.error);});
}
IDBDatabase.prototype.transaction=function(names,mode,...rest){
 if(mode!=='readwrite')return original.call(this,names,mode,...rest);
 const r={index:rows.length+1,scope:[].concat(names)};rows.push(r);
 const capture=stage=>sample(this).then(v=>r[stage]=v,e=>r[stage]={unavailable:e?.name});
 capture('before');const t=original.call(this,names,mode,...rest);for(const name of ['complete','abort'])t.addEventListener(name,()=>{r.event=name;capture('after')});return t;
};
process.on('beforeExit',()=>writeFileSync(process.env.JOURNAL,JSON.stringify(rows)));
