import os
import json,tempfile
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parent
allowed={'index.html','storage.mjs','canonical.mjs','definitions.mjs','backup.mjs','backup-ui.mjs','restore.mjs','restore-ui.mjs','import-backup.mjs','import-json.mjs','reapply.mjs','file-save.mjs'}
read="""async()=>{const {openDatabase,CanonicalStore}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{return await s.read()}finally{s.close()}}"""
log={}
def mark(case,**v):log.setdefault(case,[]).append(v)
with sync_playwright() as w:
 for apply_first in [False,True]:
  with tempfile.TemporaryDirectory() as profile:
   def boot():
    ctx=w.chromium.launch_persistent_context(profile,executable_path=os.environ.get('YTK_CHROMIUM', '/tmp/chromium' if Path('/tmp/chromium').is_file() else None),args=['--no-sandbox'],viewport={'width':390,'height':844})
    def route(r):
     path=urlparse(r.request.url);name=path.path.removeprefix('/').removeprefix('src/')
     if path.netloc=='localhost' and name in allowed:r.fulfill(body=(root/name).read_bytes(),content_type='text/html' if name=='index.html' else 'text/javascript')
     else:r.abort()
    ctx.route('**/*',route);page=ctx.pages[0];page.set_default_timeout(5000);page.goto('http://localhost/index.html');page.locator('#restore-file').wait_for();return ctx,page
   c,p=boot()
   def loc(v):return p.locator('#'+v)
   def verify():
    loc('restore-file').set_input_files(root/'fixture-data/EM-FULL.json');loc('restore-verify').click();loc('restore-ack').check();expect(loc('restore-commit')).to_be_enabled()
   def db():return p.evaluate(read)
   ack=p.locator('#backup-panel input[type=checkbox]');ack.check();normal=p.get_by_role('button',name='通常バックアップを作成',exact=True)
   if normal.is_enabled():
    normal.click();expect(p.locator('#backup-panel')).to_contain_text('空のバックアップは作成しません')
   assert db() is None;mark('F3:N-01',empty=True,normalDisabled=normal.is_disabled(),panel=p.locator('#backup-panel').inner_text())
   verify();loc('restore-commit').click();expect(loc('reapply-review')).to_be_enabled();restored=db()
   if apply_first:
    loc('reapply-review').click();loc('reapply-ack').check();loc('reapply-commit').click();p.wait_for_function("document.querySelector('#restore-status').textContent.includes('適用') && !document.querySelector('#reapply-review').disabled")
    p.wait_for_function('async()=>('+read+')().then(d=>d.globalRevision===2)')
   if apply_first:
    original=p;other=c.new_page();other.goto('http://localhost/index.html');p=other;originalData=db();verify();expect(loc('reapply-review')).to_be_disabled();assert db()==originalData
    mark('F3:R05-20',secondTabReviewDisabled=True,existingRevision=originalData['globalRevision']);other.close();p=original
   d=db();p.reload();loc('restore-file').wait_for();expect(loc('reapply-review')).to_be_disabled();expect(loc('reapply-commit')).to_be_disabled();assert db()==d;verify();expect(loc('reapply-review')).to_be_disabled();assert db()==d;mark('F3:R05-'+('31' if apply_first else '30'),revision=d['globalRevision'],receiptsOnUI=False)
   c.close();c,p=boot();assert db()==d;expect(loc('reapply-review')).to_be_disabled();mark('F3:R05-35',fileSelected=loc('restore-file').input_value(),reviewDisabled=True,status=loc('restore-status').inner_text())
   verify();expect(loc('reapply-review')).to_be_disabled();expect(loc('reapply-commit')).to_be_disabled();assert db()==d
   reason=p.evaluate('''async()=>{const {ReapplySession}=await import('./src/reapply.mjs'),{CanonicalStore,openDatabase}=await import('./src/storage.mjs');const s=new CanonicalStore(await openDatabase());try{new ReapplySession(s,{dataset:await s.read()});return null}catch(e){return e.code}finally{s.close()}}''')
   assert reason=='UNPROVEN';mark('F3:R05-32',reason=reason,applyFirst=apply_first,needsExplicitRestore=True,revision=d['globalRevision'])
   actual=next(v['usageStatus'] for v in d['categories'] if v['categoryKey']=='mail');assert actual==('using' if apply_first else 'unanswered');mark('F3:R05-'+('33' if apply_first else '34'),mail=actual,reviewDisabled=True,applyDisabled=True,status=loc('restore-status').inner_text()); 
   if not apply_first:
    loc('restore-commit').click();expect(loc('reapply-review')).to_be_enabled();loc('reapply-review').click();assert loc('reapply-commit').is_disabled();loc('reapply-ack').check();loc('reapply-commit').click();p.wait_for_function('async()=>('+read+')().then(d=>d.globalRevision===2)');assert next(v['usageStatus'] for v in db()['categories'] if v['categoryKey']=='mail')=='using'
   c.close()
(root/'restart-results.json').write_text(json.dumps(log,ensure_ascii=False));print(list(log))
