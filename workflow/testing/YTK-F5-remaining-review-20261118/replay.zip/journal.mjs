import {writeFileSync} from 'node:fs';
import {CanonicalStore} from './storage.mjs';
import {fingerprint} from './setup.mjs';
const old=CanonicalStore.prototype.save,rows=[];
async function raw(db){
 const names=[...db.objectStoreNames];return new Promise((yes,no)=>{const t=db.transaction(names,'readonly'),out={};for(const n of names){const q=t.objectStore(n).getAll();q.onsuccess=()=>out[n]=q.result}t.oncomplete=()=>yes(fingerprint(Object.fromEntries(names.map(n=>[n,out[n]]))));t.onabort=no});
}
CanonicalStore.prototype.save=async function(expected,operation,...opts){
 const before=await raw(this.db),record={operation,expected:expected?fingerprint(expected):null,before};rows.push(record);
 try{const out=await old.call(this,expected,operation,...opts);record.end='complete';record.global=out?.globalRevision;return out}catch(e){record.end='abort';record.reason=e.code??e.name;throw e}finally{record.after=await raw(this.db);record.canonical=await this.read().then(x=>fingerprint(x));}
};
process.on('beforeExit',()=>writeFileSync(process.env.JOURNAL,JSON.stringify(rows)));
