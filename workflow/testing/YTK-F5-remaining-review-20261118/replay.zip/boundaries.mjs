import assert from 'node:assert/strict';
import {writeFileSync,readFileSync} from 'node:fs';
import * as C from './canonical.mjs';
import {fixtures,parse,sign,envelope,read,newStore,install,cat,fingerprint,snapshot} from './setup.mjs';
import {prepareRestore,commitRestore,inspectCurrent} from './restore.mjs';
import {IDBFactory} from 'fake-indexeddb';
import {CanonicalStore,openDatabase} from './storage.mjs';
const proof={},add=(group,n,v)=>(proof[group+'-'+String(n).padStart(2,'0')]??=[]).push(v);
const file=id=>JSON.parse(readFileSync('fixture-data/'+id+'.json','utf8'));
for(const [i,size] of [9999999,10000000,10000001].entries()){
 const obj=file('FILE-DS-'+size);assert.equal(C.capacity(obj.snapshot),size);let writes=0;const s=await newStore(),tx=s.db.transaction.bind(s.db);s.db.transaction=(a,m)=>{if(m==='readwrite')writes++;return tx(a,m)};
 const preview=async()=>prepareRestore(s,await parse(obj));if(size>1e7)await assert.rejects(preview());else assert.equal((await preview()).services,obj.snapshot.services.length);
 assert.equal(writes,0);add('F3:R03',14+i,{file:fingerprint(obj),size,writes});s.close();
}
const write=(s,name,value)=>new Promise((yes,no)=>{const t=s.db.transaction(name,'readwrite');t.objectStore(name).put(value);t.oncomplete=yes;t.onabort=no});
for(const n of [1,2,3,4,5,7,8,9,10,11,12,13,46]){
 const fac=new IDBFactory(),s=new CanonicalStore(await openDatabase(fac)),other=new CanonicalStore(await openDatabase(fac)),obj=file('V-VALID-01'),t=await parse(obj);
 if([1,8,9,10,13].includes(n))await install(s,t);
 if([3,7,11].includes(n))await write(s,'meta',{key:'current',damaged:1});
 if(n===5)await write(s,'categories',obj.snapshot.categories[0]);
 if(n===4)s.close();
 const old=await inspectCurrent(s);const expected=({1:'VALID',2:'EMPTY',3:'CORRUPT_COMPARABLE',4:'CORRUPT_UNCOMPARABLE',5:'CORRUPT_COMPARABLE',7:'CORRUPT_COMPARABLE'})[n];
 if(expected)assert.equal(old.classification,expected);
 if(n===4)await assert.rejects(prepareRestore(s,t),{code:'UNCOMPARABLE'});
 if(n===7){const p=await prepareRestore(s,t);for(const flags of [{},{confirmed:true},{corruptConfirmed:true}]){await assert.rejects(commitRestore(s,p,flags),{code:'CONFIRMATION'});assert.deepEqual((await inspectCurrent(other)).rawGuard,old.rawGuard);}await commitRestore(s,p,{confirmed:true,corruptConfirmed:true});assert.equal((await inspectCurrent(other)).classification,'VALID');}
 if(n>=8&&n<=13){const p=await prepareRestore(s,t);
  if(n===11)await write(other,'meta',{key:'current',damaged:2});else if(n===10)await install(other,t);else await other.save(await other.read(),n===9?{type:'deleteAll'}:cat('social','unknown'));
  const before=(await inspectCurrent(other)).rawGuard,tx=s.db.transaction.bind(s.db);let clears=0;
  s.db.transaction=(a,m)=>{const trans=tx(a,m);if(m==='readwrite')for(const name of a){const st=trans.objectStore(name),fn=st.clear.bind(st);st.clear=()=>{clears++;return fn()}}return trans};
  await assert.rejects(commitRestore(s,p,{confirmed:true,corruptConfirmed:true}),{code:'CONFLICT'});if(n===13)await assert.rejects(commitRestore(s,p,{confirmed:true,corruptConfirmed:true}),{code:'PLAN_STATE'});assert.equal(clears,0);assert.deepEqual((await inspectCurrent(other)).rawGuard,before);
 }
 if(n===46){const bad=structuredClone(obj.snapshot);bad.services[1].recordId=bad.services[0].recordId;await assert.rejects(parse(sign(envelope(bad))));assert.equal(await s.read(),null);}
 add('F3:R03',n,{input:fingerprint(obj),classification:old.classification,after:(await inspectCurrent(other)).classification});s.close();other.close();
}
for(const id of ['DS-MIX','DS-CONDITIONAL']){
 const fixture=file(id),s=await newStore();await install(s,await parse(sign(envelope(fixture))));let d=await s.read();
 for(const c of d.categories.filter(c=>c.usageStatus==='unanswered')){
  const key=c.categoryKey,rid=C.id('svc'),op={type:'addService',categoryKey:key,recordId:rid,serviceCatalogId:'other',otherServiceName:'試験用'};
  await s.save(d,op);d=await s.read();const rec=d.services.find(r=>r.recordId===rid),parent=d.categories.find(r=>r.categoryKey===key);assert.equal(rec.recordState,'partial');assert.equal(rec.intentionOverride,null);assert(!('inheritedIntention' in rec));assert.deepEqual([parent.intention,parent.usageStatus],['unanswered','unanswered']);
  for(const n of [1,2])add('F2:R09',n,{id,key,rec,parent});
  const restored=await newStore();await install(restored,await parse(await snapshot(s)));const rd=await restored.read();const rs=rd.services.find(r=>r.recordId===rid);assert.equal(C.effectiveIntention(rs,rd.categories.find(r=>r.categoryKey===key)),'undecided');assert.deepEqual(rs,rec);add('F2:R09',6,{id,key,restored:fingerprint(rd)});restored.close();
  const before=d;await s.save(d,{type:'service',recordId:rid,field:'usageStatus',value:'using'});d=await s.read();const cx=d.categories.find(r=>r.categoryKey===key),sr=d.services.find(r=>r.recordId===rid);
  assert.deepEqual([cx.usageStatus,cx.intention,sr.usageStatus,cx.revision-parent.revision,sr.revision-rec.revision,d.globalRevision-before.globalRevision],['using','undecided','using',1,1,1]);
  for(const n of [9,11])add('F2:R09',n,{id,key,before:fingerprint(before),after:fingerprint(d)});
  await s.save(d,{type:'category',categoryKey:key,field:'intention',value:'keep'});let changed=await s.read();assert.deepEqual(changed.services,d.services);assert.equal(C.effectiveIntention(sr,changed.categories.find(r=>r.categoryKey===key)),'keep');add('F2:R09',7,{id,key,unchangedServices:fingerprint(changed.services)});
  await s.save(changed,{type:'service',recordId:rid,field:'intentionOverride',value:'delete'});changed=await s.read();await s.save(changed,{type:'category',categoryKey:key,field:'intention',value:'family'});d=await s.read();assert.deepEqual(d.services,changed.services);assert.equal(C.effectiveIntention(d.services.find(r=>r.recordId===rid),d.categories.find(r=>r.categoryKey===key)),'delete');add('F2:R09',8,{id,key,override:'delete'});
 }
 s.close();
}
writeFileSync('boundary-results.json',JSON.stringify(proof));console.log(Object.keys(proof).length)
